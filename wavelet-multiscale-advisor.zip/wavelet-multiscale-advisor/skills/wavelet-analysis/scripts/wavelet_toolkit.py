#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小波工具箱（numpy 内置实现 + 可选 PyWavelets）

设计目标：**装不上 PyWavelets 也能跑**。内置 Haar 的 DWT/MODWT 与 Morlet CWT，
全部带自检；装了 PyWavelets 时可切换到更丰富的正交/双正交小波族。

用法：
  python wavelet_toolkit.py selftest
  python wavelet_toolkit.py demo
  python wavelet_toolkit.py energy --csv data.csv --col 1 --level 5

核心约定：
  - MODWT（极大重叠/非抽样）适合时序分解：平移不变、无相位偏移、系数与原始样本对齐。
  - DWT（离散/抽样）适合压缩与快速计算，但对平移敏感，重构前需记住填充长度。
  - 所有分解都是**用全样本**做的；用于金融回测时必须滚动重算，否则前视偏差。
"""

import argparse
import sys

import numpy as np

try:
    import pywt  # noqa: F401
    HAS_PYWT = True
except Exception:
    HAS_PYWT = False

SQRT2 = np.sqrt(2.0)


# ---------------------------------------------------------------- 内置 Haar

def _pad_to_multiple(x, level):
    """把长度填充到 2**level 的整数倍，保证逐层二分不出奇数长度。"""
    x = np.asarray(x, dtype=float).ravel()
    mult = 2 ** max(level, 1)
    rem = len(x) % mult
    if rem:
        x = np.concatenate([x, np.repeat(x[-1], mult - rem)])
    return x


def dwt_haar(x, level=None):
    """Haar 离散小波分解（Mallat 金字塔，下采样）。返回 (近似, [最细→最粗的细节])。"""
    x0 = np.asarray(x, dtype=float).ravel()
    maxlev = max(0, int(np.floor(np.log2(len(x0)))))
    level = maxlev if level is None else min(level, maxlev)
    if level <= 0:
        return x0.copy(), []
    x = _pad_to_multiple(x0, level)
    a = x.copy()
    details = []
    for _ in range(level):
        even, odd = a[0::2], a[1::2]
        details.append((even - odd) / SQRT2)
        a = (even + odd) / SQRT2
    return a, details


def idwt_haar(a, details):
    """Haar 重构。details 为 dwt_haar 返回的顺序（最细→最粗）。"""
    a = np.asarray(a, dtype=float)
    for d in reversed(details):
        d = np.asarray(d, dtype=float)
        out = np.empty(len(a) + len(d))
        out[0::2] = (a + d) / SQRT2
        out[1::2] = (a - d) / SQRT2
        a = out
    return a


def modwt_haar(x, J):
    """Haar 极大重叠离散小波变换（不下采样）。返回 (W[最细→最粗], V_J)。

    注意归一化：MODWT 的尺度/小波滤波器为 h/√2 与 g/√2，对 Haar 即 [1/2, 1/2] 与
    [1/2, -1/2]。用 1/√2 会破坏能量守恒并使近似层系数逐层放大。
    """
    x = np.asarray(x, dtype=float).ravel()
    W, a = [], x.copy()
    for j in range(1, J + 1):
        s = 2 ** (j - 1)
        W.append(0.5 * (a - np.roll(a, s)))
        a = 0.5 * (a + np.roll(a, s))
    return W, a


def imodwt_haar(W, V):
    """Haar MODWT 逆变换（精确重构）。"""
    a = np.asarray(V, dtype=float)
    for j in range(len(W), 0, -1):
        s = 2 ** (j - 1)
        d = np.asarray(W[j - 1], dtype=float)
        a = 0.5 * ((a + d) + np.roll(a - d, -s))
    return a


# ---------------------------------------------------------------- 通用去噪

def _sigma_from_d1(d1):
    return np.median(np.abs(d1 - np.median(d1))) / 0.6745


def denoise(x, level=3, threshold="soft", mode="modwt"):
    """小波阈值去噪。通用阈值 λ = σ·sqrt(2 ln N)，σ 由最细尺度 MAD 估计。"""
    x = np.asarray(x, dtype=float).ravel()
    N = len(x)
    if HAS_PYWT:
        coeffs = pywt.wavedec(x, "db4", mode="periodization", level=level)
        d1 = coeffs[-1]
    else:
        W, _ = modwt_haar(x, level)
        d1 = W[0]
    lam = _sigma_from_d1(d1) * np.sqrt(2 * np.log(N))

    def _th(w):
        if threshold == "soft":
            return np.sign(w) * np.maximum(np.abs(w) - lam, 0.0)
        return np.where(np.abs(w) > lam, w, 0.0)

    if HAS_PYWT:
        cs = [coeffs[0]] + [_th(c) for c in coeffs[1:]]
        return pywt.waverec(cs, "db4", mode="periodization")[:N], lam

    W, V = modwt_haar(x, level)
    rec = imodwt_haar([_th(w) for w in W], V)
    return rec, lam


# ---------------------------------------------------------------- Morlet CWT

def morlet_cwt(x, scales, omega0=6.0):
    """Morlet 连续小波变换（频域实现，Torrence & Compo 口径）。返回 |系数|，形状 (len(scales), N)。"""
    x = np.asarray(x, dtype=float).ravel()
    N = len(x)
    x = x - x.mean()
    X = np.fft.fft(x)
    w = 2 * np.pi * np.fft.fftfreq(N)
    out = np.empty((len(scales), N))
    for i, s in enumerate(scales):
        psi = np.exp(-0.5 * ((s * w - omega0) ** 2))
        psi[w < 0] = 0.0  # 解析小波，只用正频
        out[i] = np.abs(np.fft.ifft(X * psi)) * np.sqrt(s)
    return out


# ---------------------------------------------------------------- 尺度能量

def energy_by_scale(x, J):
    """MODWT 各尺度能量与占比，用于判断「信号主要活在哪个尺度」。"""
    x = np.asarray(x, dtype=float).ravel()
    W, V = modwt_haar(x, J)
    tot = float(np.sum(x ** 2))
    rows = []
    for j, w in enumerate(W, 1):
        e = float(np.sum(np.asarray(w) ** 2))
        rows.append((f"d{j}", e, e / tot if tot else np.nan))
    e = float(np.sum(V ** 2))
    rows.append((f"a{J}", e, e / tot if tot else np.nan))
    return rows


# ---------------------------------------------------------------- 自检

def selftest(verbose=True):
    rng = np.random.default_rng(20261112)
    ok = True

    # 1) DWT 重构
    for N in (256, 1000):
        x = rng.normal(size=N)
        a, ds = dwt_haar(x, level=4)
        rec = idwt_haar(a, ds)
        err = float(np.max(np.abs(rec[:N] - x)))
        ok &= err < 1e-10
        if verbose:
            print(f"[DWT ] N={N:4d} 重构最大误差 {err:.3e}")

    # 2) MODWT 重构 + 能量守恒
    for N in (256, 1000):
        x = rng.normal(size=N)
        W, V = modwt_haar(x, 5)
        rec = imodwt_haar(W, V)
        err = float(np.max(np.abs(rec - x)))
        e_sig = float(np.sum(x ** 2))
        e_dec = float(sum(np.sum(w ** 2) for w in W) + np.sum(V ** 2))
        eerr = abs(e_sig - e_dec)
        ok &= err < 1e-10 and eerr < 1e-8
        if verbose:
            print(f"[MODWT] N={N:4d} 重构最大误差 {err:.3e} | 能量守恒误差 {eerr:.3e}")

    # 3) 去噪应降低 RMSE
    N = 1024
    t = np.linspace(0, 1, N, endpoint=False)
    clean = np.sin(2 * np.pi * 5 * t) + 0.5 * np.sin(2 * np.pi * 20 * t)
    noisy = clean + rng.normal(scale=0.4, size=N)
    den, lam = denoise(noisy, level=4)
    r0 = float(np.sqrt(np.mean((noisy - clean) ** 2)))
    r1 = float(np.sqrt(np.mean((den[:N] - clean) ** 2)))
    ok &= r1 < r0
    if verbose:
        print(f"[去噪 ] λ={lam:.3f} | 含噪 RMSE {r0:.4f} → 去噪 {r1:.4f}（应下降）")

    # 4) CWT 峰值尺度应对应信号周期
    fs = 64.0
    N = 512
    t = np.arange(N) / fs
    f0 = 4.0
    x = np.sin(2 * np.pi * f0 * t)
    scales = np.array([1, 2, 4, 8, 16, 32, 64], dtype=float)
    co = morlet_cwt(x, scales)
    peak = scales[int(np.argmax(co[:, N // 4:N // 2].mean(axis=1)))]
    exp = fs / f0
    ok &= abs(peak - exp) / exp < 0.6
    if verbose:
        print(f"[CWT ] 4Hz 信号峰值尺度 {peak:g}（理论 ≈ {exp:g}，允许 ±60%）")

    if verbose:
        print("\n自检结果:", "全部通过 ✅" if ok else "存在失败 ❌")
    return ok


def demo():
    rng = np.random.default_rng(7)
    N = 512
    t = np.linspace(0, 10, N)
    trend = 0.3 * t
    cycle = np.sin(2 * np.pi * t / 2.0)
    noise = rng.normal(scale=0.5, size=N)
    x = trend + cycle + noise

    print("=== 合成信号：线性趋势 + 2 单位周期 + 噪声 ===")
    print("各尺度能量占比（MODWT, Haar）：")
    for name, e, r in energy_by_scale(x, 5):
        print(f"  {name}: {e:10.2f}  {r*100:6.2f}%")

    den, lam = denoise(x, level=4)
    print(f"\n阈值 λ = {lam:.3f}")
    print(f"原始标准差 {x.std():.3f} | 去噪后标准差 {den.std():.3f}")
    print(f"去噪序列与原序列 RMSE {np.sqrt(np.mean((den-x)**2)):.3f}（应小于原始噪声水平）")
    print(f"使用 PyWavelets: {HAS_PYWT}")
    print("\n提示：尺度 d1 约对应 2 个采样点周期，d2≈4，d3≈8 …；能量最高的尺度即主周期所在。")


def cmd_energy(args):
    data = np.genfromtxt(args.csv, delimiter=",", skip_header=1, usecols=args.col, dtype=float)
    data = data[~np.isnan(data)]
    if len(data) < 32:
        print("样本太短（<32），小波分解意义有限。")
        return
    J = args.level or min(6, int(np.log2(len(data))))
    print(f"样本 {len(data)} | 分解层数 {J}")
    for name, e, r in energy_by_scale(data, J):
        print(f"  {name}: 能量 {e:14.4f}  占比 {r*100:6.2f}%")


def main():
    ap = argparse.ArgumentParser(description="小波/多尺度分析工具箱")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("selftest", help="运行内置自检")
    p.set_defaults(func=lambda a: selftest())

    p = sub.add_parser("demo", help="合成信号演示")
    p.set_defaults(func=lambda a: demo())

    p = sub.add_parser("energy", help="CSV 单列的各尺度能量")
    p.add_argument("--csv", required=True)
    p.add_argument("--col", type=int, default=1)
    p.add_argument("--level", type=int, default=None)
    p.set_defaults(func=cmd_energy)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
