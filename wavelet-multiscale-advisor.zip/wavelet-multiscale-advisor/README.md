# 小波与多尺度分析顾问 · Wavelet & Multiscale Analysis Advisor

数学建模顾问，专长小波分析与各类「大小尺度变化」问题：选方法、定参数、指出陷阱、给可运行代码。

## 类型

Agent 型（单个 AI 专家）｜行业分类：`04-DataAI`（数据智能 · 数据分析/信号处理）

> 分类理由：核心输出物是**多尺度分析方法与尺度特征**，属于数据分析方法层；服务对象是研究者与工程师，不是投资决策本身。

## 能力范围

| 做 | 不做 |
|---|---|
| CWT/DWT/MODWT/小波包/二维小波的选型与参数设计 | 凭数据缺席臆断「有几个周期」 |
| 阈值去噪（软/硬/garrote、层相关阈值） | 保证「去噪后一定更准」 |
| 趋势-周期多尺度分解，尺度换算成物理周期 | 给投资建议、收益预测 |
| 小波相干/交叉小波/相位差/显著性/COI | 把合成演示当作用户数据的结论 |
| DFA/MF-DFA 长程相关与多重分形 | 替代用户做实际计算 |
| 金融时序防前视的滚动/扩展窗口方案 | 隐瞒边界效应与参数选择 |

## 知识库结构

```
skills/wavelet-analysis/
├── SKILL.md                        方法与三条铁律
├── references/
│   ├── 小波与多尺度方法手册.md     原理、CWT/DWT/MODWT/WPT、小波族、边界、去噪、相干、方法对比
│   ├── 方法选择决策树.md           按目标/数据特征选型、参数速查、成立判据
│   ├── 金融时序多尺度要点.md       前视偏差、滚动窗口、尺度↔周期、特征入模
│   └── 公式与实现速查.md           公式表 + PyWavelets 代码模板 + 滚动特征模板
└── scripts/wavelet_toolkit.py      DWT/MODWT/去噪/Morlet CWT/尺度能量/自检
```

## 工具自检结果（本机实测）

```
[DWT ] N= 256 重构最大误差 8.882e-16
[DWT ] N=1000 重构最大误差 1.332e-15
[MODWT] N= 256 重构最大误差 4.441e-16 | 能量守恒误差 0.000e+00
[MODWT] N=1000 重构最大误差 4.441e-16 | 能量守恒误差 0.000e+00
[去噪 ] λ=1.114 | 含噪 RMSE 0.4072 → 去噪 0.1228
[CWT ] 4Hz 信号峰值尺度 16（理论 ≈ 16）
自检结果: 全部通过
```

依存：**仅需 numpy**。装了 PyWavelets 会自动用于更丰富的小波族；未装则用内置 Haar 实现，功能不受阻。

```bash
SK="C:/Users/Administrator/.workbuddy/plugins/marketplaces/my-experts/plugins/wavelet-multiscale-advisor/skills/wavelet-analysis"
python "$SK/scripts/wavelet_toolkit.py" selftest
python "$SK/scripts/wavelet_toolkit.py" demo
python "$SK/scripts/wavelet_toolkit.py" energy --csv data.csv --col 1 --level 5
```

## 使用示例

- 帮我判断这段非平稳序列该用小波还是傅里叶，并给出分析方案
- 用 MODWT 把这条时间序列拆成趋势和不同周期的成分，说明每层对应多少天
- 小波去噪后做回测，怎么避免前视偏差？给我可执行的滚动方案

## 头像

⚠️ `avatars/expert.png` **尚未生成**（本次跳过图像生成）。`avatars/.gitkeep` 已占位，不影响校验与注册。可手动放入 PNG/JPG（512×512，≤500KB），或后续用 ImageGen 生成，推荐 prompt：

```
Professional cartoon-style illustration avatar, a mathematical modeling advisor specialized
in wavelet and multiscale analysis, wearing a neat dark shirt, gesturing toward a
time-frequency heatmap and stacked multiresolution wave bands, calm precise expression,
waveform squiggles and scale-axis symbols floating in the background.
Bust shot, facing forward. Clean simple dark teal background.
High quality, professional, natural.
```

生成时 `size` 用 `1024x1024`，输出到 `avatars/`，重命名为 `expert.png`。

## 安装与注册

```
C:/Users/Administrator/.workbuddy/plugins/marketplaces/my-experts/plugins/wavelet-multiscale-advisor/
```

```bash
python scripts/validate_expert.py <expert-dir>
python scripts/register_expert.py <expert-dir> --session-id <session-id>
python scripts/package_expert.py <expert-dir> [output-dir]
```

## 免责声明

本专家提供方法与实现建议，不构成对具体数据的结论。任何分解结果、周期判断、去噪效果都依赖实际数据与参数，须自行计算并检验；用于金融场景时务必做滚动/样本外验证。
