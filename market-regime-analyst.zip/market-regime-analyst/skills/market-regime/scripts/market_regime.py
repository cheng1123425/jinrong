# -*- coding: utf-8 -*-
"""
市场状态判定工具（小牛市 / 大牛市 / 结构行情 / 熊市）
仅依赖 numpy + 标准库。所有指标可复算，所有分母可追溯。

用法：
    python market_regime.py --selftest
    python market_regime.py --run --panel <panel.pkl> [--start 2025-01-01]

panel.pkl 结构（dict）：
    {code: {"dates": [...], "name": [...], "o": [], "h": [], "l": [], "c": [], "pc": [], "v": [], "fmv": []}}
    至少需要 dates / name / c / v；fmv 缺失时用等权指数替代市值加权。

输出纪律（见 references/判据阈值速查.md）：
    - 分档必须同时给"匹配度分"与"失效条件"
    - 缺维必须标注并重归一权重，不得静默按 0 或 50 计分
    - 比值必须配绝对分位，防低基数虚高
"""
import argparse
import json
import math
import os
import pickle
import sys

import numpy as np

# ----------------------------- 基础统计 -----------------------------

def rolling_mean(x, w, i):
    """x[i] 往前 w 个观测的均值（不含未来）。"""
    lo = max(0, i - w + 1)
    seg = x[lo:i + 1]
    return float(np.mean(seg)) if len(seg) else float("nan")


def rolling_ratio(x, short, long, i):
    """滚动比值：短窗均值 / 长窗均值。分母不足 30 个观测返回 nan。"""
    lo = max(0, i - long + 1)
    if i - lo + 1 < 30:
        return float("nan")
    den = float(np.mean(x[lo:i + 1]))
    if den <= 0:
        return float("nan")
    return rolling_mean(x, short, i) / den


def pct_rank(x, i, window=500):
    """滚动分位（0-100），只使用 i 及之前的数据。"""
    lo = max(0, i - window + 1)
    seg = np.asarray(x[lo:i + 1], dtype=float)
    seg = seg[~np.isnan(seg)]
    if len(seg) < 30:
        return float("nan")
    return float((seg <= x[i]).sum() / len(seg) * 100.0)


def max_drawdown(nav):
    nav = np.asarray(nav, dtype=float)
    peak = np.maximum.accumulate(nav)
    return float((nav / peak - 1).min() * 100.0)  # 负数，单位 %


def _piecewise(v, pts):
    """分段线性映射。pts = [(输入, 输出), ...] 输入递增。"""
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return float("nan")
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    if v <= xs[0]:
        return float(ys[0])
    if v >= xs[-1]:
        return float(ys[-1])
    for k in range(len(xs) - 1):
        if xs[k] <= v <= xs[k + 1]:
            t = (v - xs[k]) / (xs[k + 1] - xs[k])
            return float(ys[k] + t * (ys[k + 1] - ys[k]))
    return float(ys[-1])


# ----------------------------- 打分 -----------------------------

WEIGHTS = {"price": 0.30, "volume": 0.25, "breadth": 0.30, "sentiment": 0.15}


def score_price(ret120, ma_pos):
    """ret120: 120日涨幅(%)；ma_pos: close/MA200 - 1 (%)"""
    s1 = _piecewise(ret120, [(-30, 0), (-15, 15), (0, 45), (10, 62), (25, 80), (50, 95)])
    s2 = _piecewise(ma_pos, [(-15, 0), (-5, 30), (0, 50), (8, 75), (20, 95)])
    return 0.7 * s1 + 0.3 * s2


def score_volume(vol_ratio):
    return _piecewise(vol_ratio, [(0.6, 5), (0.85, 25), (1.0, 45), (1.15, 60),
                                  (1.3, 78), (1.6, 90), (2.2, 70)])


def score_breadth(b20):
    return _piecewise(b20, [(20, 0), (30, 15), (40, 35), (50, 55), (60, 78), (70, 90), (80, 95)])


def score_sentiment(limit_ratio, vol_pct):
    s1 = _piecewise(limit_ratio, [(0.5, 5), (1, 20), (2, 40), (4, 62), (8, 82), (15, 90)])
    s2 = _piecewise(vol_pct, [(10, 15), (30, 35), (50, 50), (75, 70), (92, 88), (99, 95)])
    return 0.6 * s1 + 0.4 * s2


def composite(dims, weights=None):
    """dims: {name: value or None}。None 表示该维缺失 → 权重重归一。"""
    w = dict(WEIGHTS if weights is None else weights)
    avail = {k: v for k, v in dims.items() if v is not None and not (isinstance(v, float) and math.isnan(v))}
    missing = [k for k in w if k not in avail]
    wsum = sum(w[k] for k in avail)
    if wsum <= 0:
        return float("nan"), missing
    total = sum(dims[k] * w[k] for k in avail) / wsum
    return float(total), missing


# ----------------------------- 分档 -----------------------------

def classify(ret120, breadth20, vol_ratio, divergence, ma_pos, mdd120, vol_pct=None):
    """
    返回 (档位, 理由列表)。参数单位：涨幅/回撤为 %，广度与分位为 0-100，比值为倍数。
    divergence: 指数涨幅 - 个股涨幅中位数（pp）
    """
    why = []
    # 1) 熊市：跌幅够深 + 广度持续差
    if ret120 <= -15 and breadth20 < 40:
        why.append(f"120日 {ret120:+.1f}% 且广度 {breadth20:.0f}% < 40%")
        return "熊市", why
    # 2) 熊市反弹：涨了但仍在长期均线下方、无量、广度不足
    if ret120 >= 10 and ma_pos < 0 and (vol_ratio < 1.0 or math.isnan(vol_ratio)) and breadth20 < 50:
        why.append(f"涨 {ret120:+.1f}% 但 close 低于 MA200 {ma_pos:+.1f}%，量能比 {vol_ratio:.2f} < 1.0")
        why.append(f"广度仅 {breadth20:.0f}%")
        return "熊市反弹", why
    # 3) 大牛市：四维同步
    if (ret120 >= 25 and breadth20 >= 60 and not math.isnan(vol_ratio)
            and 1.3 <= vol_ratio <= 2.5 and mdd120 >= -12):
        why.append(f"涨幅 {ret120:+.1f}% ≥ 25%")
        why.append(f"广度 {breadth20:.0f}% ≥ 60%（普涨）")
        why.append(f"量能比 {vol_ratio:.2f} ∈ [1.3, 2.5]（增量资金）")
        why.append(f"期间最大回撤 {mdd120:.1f}%，未破 12%")
        return "大牛市", why
    # 4) 情绪牛：量能异常但广度不支持
    if ret120 >= 15 and not math.isnan(vol_ratio) and vol_ratio >= 1.5 and (
            breadth20 < 55 or (vol_pct is not None and not math.isnan(vol_pct) and vol_pct >= 92)):
        why.append(f"涨幅 {ret120:+.1f}% 但广度仅 {breadth20:.0f}%")
        why.append(f"量能比 {vol_ratio:.2f} ≥ 1.5（异常放量，非普涨驱动）")
        return "情绪牛", why
    # 5) 小牛市：涨了，但广度窄 + 结构背离
    if ret120 >= 8 and breadth20 < 60 and divergence >= 5:
        why.append(f"涨幅 {ret120:+.1f}% ≥ 8% 但广度仅 {breadth20:.0f}% < 60%")
        why.append(f"指数跑赢个股中位数 {divergence:.1f}pp ≥ 5pp（结构行情）")
        return "小牛市", why
    # 6) 小牛市（广度略高但背离明显）
    if ret120 >= 8 and divergence >= 8:
        why.append(f"涨幅 {ret120:+.1f}%，指数跑赢中位数 {divergence:.1f}pp")
        return "小牛市", why
    # 6b) 牛市初段：广度已达标但涨幅未到大牛市门槛（宁可标小牛市，不标弱势）
    if ret120 >= 8 and breadth20 >= 60:
        why.append(f"广度 {breadth20:.0f}% ≥ 60%（普涨）但涨幅 {ret120:+.1f}% 未达大牛市 25% 门槛")
        why.append("属牛市初段：参与度已确认，趋势强度待观察")
        return "小牛市", why
    # 7) 震荡
    if abs(ret120) < 8:
        why.append(f"120日涨幅 {ret120:+.1f}%，落在 ±8% 区间")
        return "震荡/存量", why
    why.append(f"涨幅 {ret120:+.1f}%、广度 {breadth20:.0f}%、量能比 {vol_ratio:.2f} 未满足任何分档组合")
    return "弱势", why


def evaluate_snapshot(snap):
    """
    snap 需含：ret120, breadth20, vol_ratio, divergence, ma_pos, mdd120, vol_pct, limit_ratio
    返回 dict：各维分数、总分、档位、理由、缺失维、低基数告警
    """
    sp = score_price(snap["ret120"], snap["ma_pos"])
    sv = score_volume(snap["vol_ratio"])
    sb = score_breadth(snap["breadth20"])
    ss = score_sentiment(snap.get("limit_ratio", float("nan")), snap.get("vol_pct", float("nan")))
    dims = {"price": sp, "volume": sv, "breadth": sb, "sentiment": ss}
    total, missing = composite(dims)
    regime, why = classify(snap["ret120"], snap["breadth20"], snap["vol_ratio"],
                           snap["divergence"], snap["ma_pos"], snap["mdd120"],
                           snap.get("vol_pct"))
    # 低基数虚高告警：比值高但绝对分位低
    warn = []
    vp = snap.get("vol_pct", float("nan"))
    if not math.isnan(snap["vol_ratio"]) and snap["vol_ratio"] >= 1.3 and not math.isnan(vp) and vp < 50:
        warn.append(f"量能比 {snap['vol_ratio']:.2f} 偏高但成交额仅历史 {vp:.0f} 分位 → 低基数虚高，比值不可单用")
    if missing:
        warn.append("缺失维度：" + "、".join(missing) + "（权重已重归一，结论不可与大牛市档位直接比较）")
    return {"dims": dims, "total": total, "regime": regime, "why": why,
            "missing": missing, "warnings": warn}


# ----------------------------- 从面板构建市场序列 -----------------------------

def _limit_pct(code, name):
    """按板块与 ST 状态返回涨停幅度（小数）。"""
    c = code.lower()
    if "st" in name.lower():
        return 0.05
    if c.startswith("bj"):
        return 0.30
    if c.startswith("sh688") or c.startswith("sz30"):
        return 0.20
    return 0.10


def build_market_series(panel, start=None, end=None):
    """
    返回按日期升序的列表，每项含：
      date, n, breadth(上涨占比%), ew_ret(等权指数日收益%), cap_ret(市值加权日收益%),
      med_ret(个股中位数收益%), amount(成交量合计), limit_up, limit_down, max_streak
    """
    buckets = {}
    for code, d in panel.items():
        dates = d.get("dates") or []
        closes = d.get("c") or []
        vols = d.get("v") or []
        names = d.get("name") or []
        fmvs = d.get("fmv") or []
        n = min(len(dates), len(closes), len(vols))
        if n < 2:
            continue
        for i in range(1, n):
            dt = dates[i]
            if start and dt < start:
                continue
            if end and dt > end:
                continue
            pc = closes[i - 1]
            c = closes[i]
            if not pc or pc <= 0 or not c or c <= 0:
                continue
            r = c / pc - 1.0
            nm = names[i] if i < len(names) else ""
            fmv = fmvs[i] if i < len(fmvs) and fmvs[i] > 0 else 0.0
            b = buckets.get(dt)
            if b is None:
                b = buckets[dt] = {"r": [], "w": [], "vol": 0.0, "up": 0, "dn": 0,
                                   "lu": 0, "ld": 0, "streak": {}}
            b["r"].append(r)
            b["w"].append(fmv)
            b["vol"] += vols[i] if i < len(vols) else 0.0
            if r > 0:
                b["up"] += 1
            elif r < 0:
                b["dn"] += 1
            lim = _limit_pct(code, nm)
            if r >= lim * 0.98:
                b["lu"] += 1
            elif r <= -lim * 0.98:
                b["ld"] += 1

    out = []
    for dt in sorted(buckets):
        b = buckets[dt]
        r = np.asarray(b["r"], float)
        w = np.asarray(b["w"], float)
        tot = b["up"] + b["dn"]
        breadth = (b["up"] / tot * 100.0) if tot else float("nan")
        cap = float(np.sum(r * w) / np.sum(w) * 100.0) if np.sum(w) > 0 else float(np.mean(r) * 100)
        out.append({
            "date": dt, "n": len(r),
            "breadth": breadth,
            "ew_ret": float(np.mean(r) * 100.0),
            "cap_ret": cap,
            "med_ret": float(np.median(r) * 100.0),
            "amount": b["vol"],
            "limit_up": b["lu"], "limit_down": b["ld"],
        })
    return out


def snapshot_at(series, i, win=120):
    """在索引 i 处计算快照（只用 i 及之前的数据）。"""
    if i < 1:
        return None
    ew = np.array([s["ew_ret"] for s in series], float) / 100.0
    nav = np.cumprod(1 + ew)
    lo = max(0, i - win + 1)
    ret120 = (nav[i] / nav[lo] - 1) * 100 if nav[lo] > 0 else float("nan")
    ma200 = np.mean(nav[max(0, i - 199):i + 1])
    ma_pos = (nav[i] / ma200 - 1) * 100 if ma200 > 0 else float("nan")
    breadth = np.array([s["breadth"] for s in series], float)
    amount = np.array([s["amount"] for s in series], float)
    b20 = rolling_mean(breadth, 20, i)
    vol_ratio = rolling_ratio(amount, 20, 120, i)
    vol_pct = pct_rank(amount, i, 500)
    lu = np.array([s["limit_up"] for s in series], float)
    ld = np.array([s["limit_down"] for s in series], float)
    limit_ratio = rolling_mean(lu, 20, i) / max(rolling_mean(ld, 20, i), 1.0)
    mdd120 = max_drawdown(nav[lo:i + 1])
    # 结构背离：市值加权 120 日涨幅 - 个股中位数的 120 日复利
    cap = np.array([s["cap_ret"] for s in series], float) / 100.0
    med = np.array([s["med_ret"] for s in series], float) / 100.0
    cap_nav = np.cumprod(1 + cap)
    med_nav = np.cumprod(1 + med)
    div = (cap_nav[i] / cap_nav[lo] - 1) * 100 - (med_nav[i] / med_nav[lo] - 1) * 100
    return {"ret120": ret120, "breadth20": b20, "vol_ratio": vol_ratio,
            "divergence": div, "ma_pos": ma_pos, "mdd120": mdd120,
            "vol_pct": vol_pct, "limit_ratio": limit_ratio,
            "index_ret_ew": ret120, "index_ret_cap": (cap_nav[i] / cap_nav[lo] - 1) * 100,
            "med_ret120": (med_nav[i] / med_nav[lo] - 1) * 100}


# ----------------------------- 自检 -----------------------------

def _chk(name, ok, detail=""):
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f"  {detail}" if detail else ""))
    return ok


def selftest():
    print("=== 市场状态判定工具 自检 ===")
    ok = True

    # 1) 滚动比值：常数序列 = 1.0，且不使用未来数据
    x = [100.0] * 200
    r = rolling_ratio(x, 20, 120, 199)
    ok &= _chk("常数序列量能比 = 1.000", abs(r - 1.0) < 1e-9, f"{r:.6f}")
    x2 = list(x[:180]) + [300.0] * 20
    ok &= _chk("末段放量后量能比 > 1.5", rolling_ratio(x2, 20, 120, 199) > 1.5,
               f"{rolling_ratio(x2, 20, 120, 199):.3f}")
    ok &= _chk("未来数据不影响历史点", abs(rolling_ratio(x2, 20, 120, 150) - 1.0) < 1e-9,
               f"{rolling_ratio(x2, 20, 120, 150):.6f}")

    # 2) 滚动分位：单调递增序列末端应为 100
    mono = list(range(200))
    ok &= _chk("单调序列末端分位 = 100", abs(pct_rank(mono, 199, 500) - 100) < 1e-9,
               f"{pct_rank(mono, 199, 500):.1f}")
    ok &= _chk("分位不受未来影响", abs(pct_rank(mono, 99, 500) - 100) < 1e-9)

    # 3) 最大回撤
    nav = [100, 120, 90, 110]
    ok &= _chk("最大回撤 = -25.0%", abs(max_drawdown(nav) + 25.0) < 1e-6, f"{max_drawdown(nav):.1f}%")

    # 4) 分档：四个典型场景
    cases = [
        ("大牛市", dict(ret120=32, breadth20=68, vol_ratio=1.45, divergence=3,
                        ma_pos=12, mdd120=-8, vol_pct=85, limit_ratio=7)),
        ("小牛市", dict(ret120=13, breadth20=50, vol_ratio=1.12, divergence=9,
                        ma_pos=4, mdd120=-11, vol_pct=62, limit_ratio=3)),
        ("熊市", dict(ret120=-24, breadth20=32, vol_ratio=0.75, divergence=-2,
                      ma_pos=-14, mdd120=-26, vol_pct=12, limit_ratio=0.6)),
        ("熊市反弹", dict(ret120=14, breadth20=44, vol_ratio=0.9, divergence=-1,
                          ma_pos=-6, mdd120=-9, vol_pct=30, limit_ratio=2)),
        ("震荡/存量", dict(ret120=2, breadth20=48, vol_ratio=1.02, divergence=1,
                           ma_pos=0.5, mdd120=-7, vol_pct=45, limit_ratio=2)),
        ("情绪牛", dict(ret120=22, breadth20=48, vol_ratio=1.85, divergence=6,
                        ma_pos=10, mdd120=-14, vol_pct=96, limit_ratio=9)),
    ]
    for expect, snap in cases:
        e = evaluate_snapshot(snap)
        ok &= _chk(f"分档: {expect}", e["regime"] == expect,
                   f"实得 {e['regime']} | 总分 {e['total']:.0f}")

    # 5) 大小牛市的区分必须由广度与背离决定，而非涨幅
    big = evaluate_snapshot(dict(ret120=30, breadth20=42, vol_ratio=1.1, divergence=12,
                                 ma_pos=8, mdd120=-10, vol_pct=60, limit_ratio=3))
    ok &= _chk("涨幅 30% 但广度低 → 不判大牛市", big["regime"] != "大牛市", f"实得 {big['regime']}")
    small = evaluate_snapshot(dict(ret120=10, breadth20=70, vol_ratio=1.35, divergence=-2,
                                   ma_pos=5, mdd120=-6, vol_pct=70, limit_ratio=5))
    ok &= _chk("涨幅仅 10% 但普涨+放量 → 判牛市初段（小牛市），不判震荡/弱势",
               small["regime"] == "小牛市", f"实得 {small['regime']}")

    # 6) 低基数虚高告警
    lowbase = evaluate_snapshot(dict(ret120=6, breadth20=45, vol_ratio=1.5, divergence=2,
                                     ma_pos=2, mdd120=-8, vol_pct=25, limit_ratio=2))
    ok &= _chk("低基数虚高被标记", any("低基数" in w for w in lowbase["warnings"]),
               lowbase["warnings"][0][:40] if lowbase["warnings"] else "无告警")

    # 7) 缺维重归一：广度缺失时权重重分配，不按 0 计
    full = composite({"price": 80, "volume": 80, "breadth": 80, "sentiment": 80})
    partial = composite({"price": 80, "volume": 80, "breadth": None, "sentiment": 80})
    ok &= _chk("缺维后总分仍为 80（重归一）", abs(partial[0] - 80) < 1e-9 and "breadth" in partial[1],
               f"{partial[0]:.1f}, missing={partial[1]}")
    ok &= _chk("全维总分 = 80", abs(full[0] - 80) < 1e-9, f"{full[0]:.1f}")

    # 8) 涨跌幅制度：ST 5% / 创业板 20% / 北交所 30%
    ok &= _chk("ST 涨停幅度 5%", abs(_limit_pct("sz000001", "*ST某某") - 0.05) < 1e-9)
    ok &= _chk("创业板 20%", abs(_limit_pct("sz300001", "某某") - 0.20) < 1e-9)
    ok &= _chk("科创板 20%", abs(_limit_pct("sh688001", "某某") - 0.20) < 1e-9)
    ok &= _chk("北交所 30%", abs(_limit_pct("bj920000", "某某") - 0.30) < 1e-9)
    ok &= _chk("主板 10%", abs(_limit_pct("sh600000", "某某") - 0.10) < 1e-9)

    print(f"\n自检结果: {'全部通过' if ok else '存在失败项'}")
    return 0 if ok else 1


# ----------------------------- 真实数据试跑 -----------------------------

def run(panel_path, start=None):
    with open(panel_path, "rb") as f:
        panel = pickle.load(f)
    print(f"面板股票数: {len(panel)}")
    series = build_market_series(panel, start=start)
    if not series:
        print("无可用数据")
        return 1
    print(f"交易日: {len(series)} | {series[0]['date']} ~ {series[-1]['date']}")

    # 月末取点
    idx_month_end = []
    for i in range(1, len(series)):
        if series[i]["date"][:7] != series[i - 1]["date"][:7]:
            idx_month_end.append(i - 1)
    if idx_month_end[-1] != len(series) - 1:
        idx_month_end.append(len(series) - 1)

    hdr = (f"{'日期':<12}{'状态':<8}{'总分':>5}{'120日%':>8}{'广度%':>7}{'量能比':>8}"
           f"{'背离pp':>8}{'涨停':>6}{'跌停':>6}")
    print("\n" + hdr)
    print("-" * len(hdr.encode("gbk", errors="ignore")))
    rows = []
    for i in idx_month_end:
        s = snapshot_at(series, i)
        if s is None:
            continue
        e = evaluate_snapshot(s)
        d = series[i]
        print(f"{d['date']:<12}{e['regime']:<8}{e['total']:>5.0f}{s['ret120']:>8.1f}"
              f"{s['breadth20']:>7.1f}{s['vol_ratio']:>8.2f}{s['divergence']:>8.1f}"
              f"{d['limit_up']:>6d}{d['limit_down']:>6d}")
        rows.append({"date": d["date"], "regime": e["regime"], "score": round(e["total"], 1),
                     "ret120": round(s["ret120"], 2), "breadth20": round(s["breadth20"], 1),
                     "vol_ratio": round(s["vol_ratio"], 3), "divergence": round(s["divergence"], 1),
                     "limit_up": d["limit_up"], "limit_down": d["limit_down"],
                     "warnings": e["warnings"], "why": e["why"]})

    # 最近一个交易日的完整解读
    last = series[-1]
    s = snapshot_at(series, len(series) - 1)
    e = evaluate_snapshot(s)
    print(f"\n=== 最新快照 {last['date']} ===")
    print(f"档位: {e['regime']} | 匹配度 {e['total']:.0f}/100")
    for k, v in e["dims"].items():
        print(f"  {k:<10} {v:>5.0f}")
    print("依据:")
    for w in e["why"]:
        print("  -", w)
    if e["warnings"]:
        print("告警:")
        for w in e["warnings"]:
            print("  !", w)
    print("失效条件（任一触发即重评）:")
    print(f"  F1 广度连续5日 < 40%")
    print(f"  F2 量能比连续10日 < 1.00")
    print(f"  F3 指数收盘跌破 MA200")
    print(f"  F4 涨停/跌停比连续5日 < 1.0（当前 {s['limit_ratio']:.2f}）")

    return 0, rows


def main():
    ap = argparse.ArgumentParser(description="市场状态判定（小牛市/大牛市/结构行情/熊市）")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--run", action="store_true")
    ap.add_argument("--panel", default="")
    ap.add_argument("--start", default=None)
    ap.add_argument("--json-out", default="")
    a = ap.parse_args()

    if a.selftest:
        sys.exit(selftest())
    if a.run:
        if not a.panel or not os.path.exists(a.panel):
            print("缺少 --panel 或文件不存在")
            sys.exit(2)
        res = run(a.panel, a.start)
        if isinstance(res, tuple) and a.json_out:
            with open(a.json_out, "w", encoding="utf-8") as f:
                json.dump(res[1], f, ensure_ascii=False, indent=2)
            print(f"\n已写出 {a.json_out}")
        sys.exit(0)
    ap.print_help()


if __name__ == "__main__":
    main()
