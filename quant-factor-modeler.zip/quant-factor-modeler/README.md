# 因子建模分析师 · Quant Factor Modeler

把投资逻辑建成可计算、可检验的因子，并判断它是否真的有效。基于「因子日历 2026」知识库。

## 类型

Agent 型（单个 AI 专家）｜行业分类：`08-FinanceInvestment`（金融投资 · 量化交易/投资分析）

> 分类理由：核心输出物是**因子模型与因子研究报告**，服务对象是投资与量化研究，属投资研究而非通用数据分析；数学建模是手段，不是产出归属。

## 装载的知识库

| 项 | 值 |
|---|---|
| 因子 | 367 个（编号 1–367） |
| 公式 | 729 个（编号 (1)–(729)，原 PDF 无 (280)） |
| 公式图 | `assets/eq_0001.png` … `eq_0729.png`，729 张，约 8.8 MB |
| 原文 | `因子日历2026.md`，约 476 KB / 9854 行，330 页 PDF 转换 |
| 大类 | 高频 239 / 行为金融 60 / 图谱网络 39 / 量价改进 21 / 高级 5 / 原文未标注 3 |
| 每因子结构 | 因子定义 / 变量定义 / 说明 / 参考文献 |

```
skills/factor-modeling/
├── SKILL.md                        建模与检验方法、三条铁律
├── references/
│   ├── 因子日历2026.md             367 个因子全文
│   ├── assets/                     729 张公式图（准确写法以此为准）
│   ├── factors.json                机器可读因子目录
│   ├── 因子分类索引.md             按大类分组的完整清单
│   ├── 因子库说明.md               来源、规模、已知缺陷、引用规范
│   ├── 因子检验方法论.md           IC/分层/多空/中性化/稳健性/常见错误
│   └── 债市因子方法迁移.md         股→债/转债迁移路径 + 覆盖边界
├── scripts/search_factors.py       stats/groups/list/search/show/formula
└── templates/因子研究报告模板.md
```

## 能力边界

- **做**：因子检索与公式还原、把想法建成可计算因子、pandas/numpy 实现、IC/IR 与分层多空检验、中性化与正交化、因子有效性判断、股票因子向转债/债券迁移的方法设计。
- **不做**：投资建议、个股推荐、收益预测、实盘下单、伪造或美化检验结果。
- **重要限制**：本地库是**A 股股票因子库**，全文「债」仅出现 1 次。债券/转债的因子有效性结论属方法推演，须另行取数与验证。
- **公式可靠性**：正文 alt 文本是 PDF 文本层提取，上下标会错位；39 个公式只有图片。引用公式必须看图。

## 使用示例

- 帮我把「尾盘放量后次日反转」这个想法建成可计算的因子，并给出检验方案
- 因子日历里有没有筹码分布类的因子？给我定义和公式
- 这个因子 IC 0.06，帮我判断是否真的有效，需要哪些检验

```bash
python skills/factor-modeling/scripts/search_factors.py stats
python skills/factor-modeling/scripts/search_factors.py search "筹码" --limit 10
python skills/factor-modeling/scripts/search_factors.py show 2
```

## 头像

⚠️ `avatars/expert.png` **尚未生成**（本次跳过图像生成）。`avatars/.gitkeep` 已占位，不影响校验与注册，但专家卡片暂无头像。可手动放入 PNG/JPG（512×512，≤500KB），或后续用 ImageGen 生成，推荐 prompt：

```
Professional cartoon-style illustration avatar, a quantitative factor modeling analyst,
wearing a dark shirt with rolled sleeves, standing before floating factor formulas,
scatter plots and IC time-series charts, focused analytical expression with calm confidence,
mathematical symbols and percentile bands glowing softly in the background.
Bust shot, facing forward. Clean simple dark blue with gold accent background.
High quality, professional, natural.
```

生成时 `size` 用 `1024x1024`，输出到 `avatars/`，重命名为 `expert.png`。

## 安装与注册

```
C:/Users/Administrator/.workbuddy/plugins/marketplaces/my-experts/plugins/quant-factor-modeler/
```

```bash
python scripts/validate_expert.py <expert-dir>
python scripts/register_expert.py <expert-dir> --session-id <session-id>
python scripts/package_expert.py <expert-dir> [output-dir]
```

## 免责声明

因子日历为 2026-03-02 编译的本地知识快照，因子有效性随市场结构变化。本专家产出仅供研究参考，不构成投资建议；任何策略上线前须独立完成样本外与实盘容量验证。
