#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
因子日历 2026 · 因子检索器

供「因子建模分析师」在建模前精确取回因子的定义、变量、公式与参考文献，
避免凭记忆复述因子构造。

用法（脚本自定位 references/，可从任意目录调用）：
  python search_factors.py stats
  python search_factors.py groups
  python search_factors.py list [--group 高频因子] [--json]
  python search_factors.py search "动量" [--group 图谱网络] [--limit 20]
  python search_factors.py show 2                # 按编号
  python search_factors.py show 残差反转          # 按名称关键词
  python search_factors.py formula 33            # 指定编号公式的图片与文本

约定：
  - 公式的准确写法以 `assets/eq_XXXX.png` 图片为准；`alt` 是 PDF 文本层线性提取，仅供检索（部分为空）。
  - 本库是 A 股股票因子库，不含债券因子体系，见 references/债市因子方法迁移.md。
"""

import argparse
import json
import re
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent / "references"
FACTORS = BASE / "factors.json"
MD = BASE / "因子日历2026.md"


def load():
    with FACTORS.open(encoding="utf-8") as f:
        items = json.load(f)
    items.sort(key=lambda x: x["id"])
    return items


def body_of(items, idx):
    """按行号区间切出因子原文（不含标题行）。"""
    lines = MD.read_text(encoding="utf-8").split("\n")
    start = items[idx]["line"]
    end = items[idx + 1]["line"] - 1 if idx + 1 < len(items) else len(lines)
    return "\n".join(lines[start:end]).strip()


def cmd_stats(args):
    items = load()
    fc = sum(x["formula_count"] for x in items)
    txt = sum(x["text_formula_count"] for x in items)
    print(f"因子: {len(items)} 个 | 编号公式: {fc} 个 | 有文本层: {txt} | 仅图片: {fc - txt}")
    print(f"知识库: {MD.name} ({MD.stat().st_size/1024:.0f} KB) + assets/ 公式图")


def cmd_groups(args):
    from collections import Counter
    items = load()
    c = Counter(x["group"] for x in items)
    for g, n in c.most_common():
        print(f"{g}: {n}")


def cmd_list(args):
    items = load()
    if args.group:
        items = [x for x in items if args.group in x["group"]]
    if args.json:
        print(json.dumps(items, ensure_ascii=False, indent=2))
        return
    print(f"共 {len(items)} 个因子\n")
    for x in items:
        print(f"[{x['id']}] {x['name']}  |  {x['category'] or '未分类'}  |  公式 {x['formula_count']}")


def cmd_search(args):
    items = load()
    kw = args.keyword
    if args.group:
        items = [x for x in items if args.group in x["group"]]
    hits = 0
    for x in items:
        hay = f"{x['name']} {x['category']} {x['excerpt']}"
        if kw in hay:
            hits += 1
            if hits > args.limit:
                print(f"\n... 命中超过 {args.limit}，已截断，请缩小关键词或加 --group / --limit。")
                return
            print(f"[{x['id']}] {x['name']}  |  {x['category'] or '未分类'}  |  公式 {x['formula_count']}  |  行 {x['line']}")
            print(f"    {x['excerpt'][:160]}…\n")
    if hits == 0:
        print(f"未检索到「{kw}」。可换同义表述（动量/反转/波动/流动性/资金流/筹码/网络/羊群），或 groups 查看大类。")
    else:
        print(f"命中 {hits} 个因子。用 show <编号> 取完整定义与公式。")


def cmd_show(args):
    items = load()
    key = args.key
    matched = []
    if key.isdigit():
        matched = [x for x in items if x["id"] == int(key)]
    if not matched:
        matched = [x for x in items if key in x["name"]]
    if not matched:
        print(f"未找到「{key}」。用 list 或 search 定位编号。")
        return
    if len(matched) > 1:
        print(f"「{key}」匹配 {len(matched)} 个，请用编号指定：")
        for x in matched[:15]:
            print(f"  [{x['id']}] {x['name']}")
        return
    x = matched[0]
    idx = items.index(x)
    print(f"===== [{x['id']}] {x['name']} =====")
    print(f"分类: {x['category'] or '未分类'} | 公式数: {x['formula_count']} | 原文行: {x['line']} | 锚点: {x['anchor']}")
    print(f"小节: {', '.join(x['sections']) or '—'}\n")
    print("--- 公式清单 ---")
    if not x["formulas"]:
        print("（该因子无编号公式）")
    for f in x["formulas"]:
        flag = "" if f["has_text"] else "  [无文本层，必须看图]"
        print(f"  公式({f['no']})  图片: references/{f['img']}{flag}")
        if f["alt"]:
            print(f"      文本层: {f['alt']}")
    print("\n--- 原文 ---")
    print(body_of(items, idx)[:4000])


def cmd_formula(args):
    items = load()
    no = int(args.no)
    found = []
    for x in items:
        for f in x["formulas"]:
            if f["no"] == no:
                found.append((x, f))
    if not found:
        print(f"未找到编号为 {no} 的公式。")
        return
    for x, f in found:
        print(f"公式({no}) 属于 [{x['id']}] {x['name']}")
        print(f"  图片: references/{f['img']}")
        print(f"  文本层: {f['alt'] or '（无，须看图）'}")


def main():
    ap = argparse.ArgumentParser(description="因子日历 2026 检索器")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("stats", help="库统计")
    p.set_defaults(func=cmd_stats)

    p = sub.add_parser("groups", help="大类分布")
    p.set_defaults(func=cmd_groups)

    p = sub.add_parser("list", help="列出因子")
    p.add_argument("--group", help="按大类过滤")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_list)

    p = sub.add_parser("search", help="关键词检索")
    p.add_argument("keyword")
    p.add_argument("--group")
    p.add_argument("--limit", type=int, default=20)
    p.set_defaults(func=cmd_search)

    p = sub.add_parser("show", help="查看单个因子完整条目")
    p.add_argument("key", help="编号或名称关键词")
    p.set_defaults(func=cmd_show)

    p = sub.add_parser("formula", help="按编号查公式")
    p.add_argument("no")
    p.set_defaults(func=cmd_formula)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
