#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
回撤分析与控制方案对比（纯 numpy）

功能：
  1. 从净值序列计算：回撤序列、MDD、最长水下期、Calmar、Ulcer、CDaR
  2. 对比三种控制方案：无控制 / 固定回撤止损 / 波动率目标 / 组合
  3. 自检：用已知序列验证 MDD 等口径，确认控制方案确实降回撤

用法：
  python drawdown.py --selftest
  python drawdown.py --csv nav.csv --col 1 --ann 252 --stop 0.10 --target-vol 0.15

约定：
  - 输入净值序列（不是收益率），或加 --ret 表示输入的是日收益率。
  - 止损用「策略纸面净值」判断触发，实际仓位按信号执行；涨跌停无法成交的情况需另外折算。
  - 年化按 ann 个样本/年（日频 252，周频 52，月频 12）。
"""

import argparse
import csv
import sys

import numpy as np


def nav_from_returns(r):
    r = np.asarray(r, dtype=float)
    return np.cumprod(1.0 + np.nan_to_num(r, nan=0.0))


def returns_from_nav(nav):
    nav = np.asarray(nav, dtype=float)
    r = np.empty_like(nav)
    r[0] = 0.0
    r[1:] = nav[1:] / nav[:-1] - 1.0
    return r


def drawdown_series(nav):
    nav = np.asarray(nav, dtype=float)
    peak = np.maximum.accumulate(nav)
    return nav / peak - 1.0


def max_drawdown(nav):
    nav = np.asarray(nav, dtype=float)
    dd = drawdown_series(nav)
    i_trough = int(np.argmin(dd))
    i_peak = int(np.argmax(nav[:i_trough + 1])) if i_trough > 0 else 0
    return float(dd[i_trough]), i_peak, i_trough


def longest_underwater(nav):
    nav = np.asarray(nav, dtype=float)
    peak = np.maximum.accumulate(nav)
    under = nav < peak * (1 - 1e-12)
    best = cur = 0
    for u in under:
        cur = cur + 1 if u else 0
        best = max(best, cur)
    return int(best)


def calmar(nav, ann=252):
    nav = np.asarray(nav, dtype=float)
    n = len(nav)
    if n < 2 or nav[0] <= 0:
        return float("nan")
    total = nav[-1] / nav[0]
    years = max((n - 1) / ann, 1e-9)
    cagr = total ** (1 / years) - 1
    m, _, _ = max_drawdown(nav)
    return float(cagr / abs(m)) if abs(m) > 1e-12 else float("inf")


def ulcer_index(nav):
    dd = drawdown_series(nav)
    return float(np.sqrt(np.mean(dd ** 2)) * 100)


def cdar(nav, alpha=0.05):
    dd = drawdown_series(nav)
    k = max(1, int(len(dd) * alpha))
    worst = np.sort(dd)[:k]
    return float(np.mean(worst))


def summarize(name, nav, ann=252):
    dd, ip, it = max_drawdown(nav)
    return {
        "name": name,
        "total": float(nav[-1] / nav[0] - 1),
        "mdd": dd,
        "calmar": calmar(nav, ann),
        "ulcer": ulcer_index(nav),
        "cdar5": cdar(nav, 0.05),
        "underwater": longest_underwater(nav),
        "n": len(nav),
    }


def apply_stop(r, stop=0.10, recover=0.95):
    """回撤止损：策略纸面净值回撤达 stop 时空仓，恢复到峰值的 recover 时回场。"""
    r = np.asarray(r, dtype=float)
    paper = nav_from_returns(r)
    peak = np.maximum.accumulate(paper)
    pos = 1.0
    out = np.empty_like(r)
    for i in range(len(r)):
        dd = paper[i] / peak[i] - 1.0
        if pos > 0 and dd <= -stop:
            pos = 0.0
        elif pos == 0 and paper[i] >= peak[i] * recover:
            pos = 1.0
        out[i] = r[i] * pos
    return out


def _rolling_std(x, w):
    x = np.asarray(x, dtype=float)
    out = np.full(len(x), np.nan)
    for i in range(w, len(x)):
        out[i] = np.std(x[i - w:i], ddof=0)
    return out


def apply_vol_target(r, target=0.15, window=20, wmin=0.3, wmax=1.5, ann=252):
    """波动率目标：仓位 = target / 年化实现波动，限制在 [wmin, wmax]，用昨日波动。"""
    r = np.asarray(r, dtype=float)
    vol = _rolling_std(r, window) * np.sqrt(ann)
    w = np.where(np.isnan(vol) | (vol <= 1e-9), 1.0, target / np.maximum(vol, 1e-9))
    w = np.clip(w, wmin, wmax)
    w = np.concatenate([[1.0], w[:-1]])          # 用 t-1 的波动决定 t 的仓位
    return r * w, w


def apply_combo(r, stop=0.10, recover=0.95, target=0.15, window=20, wmin=0.3, wmax=1.5, ann=252):
    r1, _ = apply_vol_target(r, target, window, wmin, wmax, ann)
    return apply_stop(r1, stop, recover)


def selftest(verbose=True):
    ok = True

    def chk(name, cond, info=""):
        nonlocal ok
        ok &= bool(cond)
        if verbose:
            print(f"[{'OK ' if cond else 'FAIL'}] {name} {info}")

    # 1) 已知 MDD
    nav = np.array([100, 120, 90, 110, 130], dtype=float)
    m, ip, it = max_drawdown(nav)
    chk("MDD 计算", abs(m - (90/120 - 1)) < 1e-12, f"{m:.4f} 峰{ip} 谷{it}")

    # 2) 最长水下期（连续处于水下的样本数）
    nav2 = np.array([100, 110, 100, 95, 105, 115, 120], dtype=float)
    chk("最长水下期", longest_underwater(nav2) == 3, f"{longest_underwater(nav2)}")

    # 3) Ulcer 与 CDaR 非负
    chk("Ulcer >= 0", ulcer_index(nav2) >= 0, f"{ulcer_index(nav2):.3f}")
    chk("CDaR <= 0", cdar(nav2) <= 0, f"{cdar(nav2):.4f}")

    # 4) 止损应降低回撤（构造深跌后反弹）
    rng = np.random.default_rng(7)
    n = 600
    r = rng.normal(0.0004, 0.018, n)
    r[100:160] -= 0.006                      # 注入一段持续下跌
    base = nav_from_returns(r)
    stopped = nav_from_returns(apply_stop(r, 0.10, 0.98))
    m0, _, _ = max_drawdown(base)
    m1, _, _ = max_drawdown(stopped)
    chk("止损降低 MDD", abs(m1) < abs(m0), f"{m0:.3f} -> {m1:.3f}")

    # 5) vol target 仓位边界
    r2, w = apply_vol_target(r, 0.15, 20, 0.3, 1.5)
    chk("vol target 仓位在界内", np.nanmin(w) >= 0.3 - 1e-9 and np.nanmax(w) <= 1.5 + 1e-9,
        f"[{np.nanmin(w):.2f},{np.nanmax(w):.2f}]")

    # 6) 组合方案无 NaN/inf
    rc = apply_combo(r)
    chk("组合方案有限值", np.all(np.isfinite(rc)))

    # 7) Calmar 方向
    chk("Calmar 有限", np.isfinite(calmar(base)) or calmar(base) == float("inf"),
        f"{calmar(base):.3f}")

    if verbose:
        print("\n自检结果:", "全部通过 ✅" if ok else "存在失败 ❌")
    return ok


def report(nav, ann=252, stop=0.10, target=0.15):
    r = returns_from_nav(nav)
    rows = [summarize("无控制", nav, ann)]
    rows.append(summarize("固定止损", nav_from_returns(apply_stop(r, stop, 0.98)), ann))
    rv, _ = apply_vol_target(r, target, 20, 0.3, 1.5, ann)
    rows.append(summarize("波动率目标", nav_from_returns(rv), ann))
    rows.append(summarize("组合方案", nav_from_returns(apply_combo(r, stop, 0.98, target)), ann))

    print(f"{'方案':<10}{'总收益':>10}{'MDD':>10}{'Calmar':>9}{'Ulcer':>9}{'CDaR5%':>9}{'最长水下':>9}")
    for x in rows:
        print(f"{x['name']:<10}{x['total']*100:>9.1f}%{x['mdd']*100:>9.1f}%"
              f"{x['calmar']:>9.2f}{x['ulcer']:>9.2f}{x['cdar5']*100:>8.1f}%{x['underwater']:>9d}")
    base, comb = rows[0], rows[-1]
    print(f"\n取舍：收益 {base['total']*100:+.1f}% → {comb['total']*100:+.1f}%"
          f"（{(comb['total']-base['total'])*100:+.1f}pp） | "
          f"MDD {base['mdd']*100:.1f}% → {comb['mdd']*100:.1f}%")
    print("提示：止损/降仓会损失部分收益，用 Calmar 与 Ulcer 综合评价，不要只看 MDD。")


def main():
    ap = argparse.ArgumentParser(description="回撤分析与控制方案")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--csv")
    ap.add_argument("--col", type=int, default=1)
    ap.add_argument("--ann", type=int, default=252)
    ap.add_argument("--stop", type=float, default=0.10)
    ap.add_argument("--target-vol", type=float, default=0.15)
    ap.add_argument("--ret", action="store_true", help="输入为收益率而非净值")
    args = ap.parse_args()

    if args.selftest:
        sys.exit(0 if selftest() else 1)
    if not args.csv:
        ap.print_help()
        sys.exit(1)

    vals = np.genfromtxt(args.csv, delimiter=",", skip_header=1, usecols=args.col)
    vals = vals[~np.isnan(vals)]
    nav = nav_from_returns(vals) if args.ret else vals
    if len(nav) < 30:
        print("样本过短（<30），回撤统计不可靠。")
        sys.exit(1)
    print(f"样本 {len(nav)} | 年化基数 {args.ann} | 止损 {args.stop:.0%} | 目标波动 {args.target_vol:.0%}\n")
    report(nav, args.ann, args.stop, args.target_vol)


if __name__ == "__main__":
    main()
