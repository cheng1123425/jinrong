# 数模分析专家 · Quant Indicator Analyst

把指标想法变成可检验的说明书，把难看的回撤变成有归因、有代价的控制方案。

## 类型

Agent 型（单个 AI 专家）｜行业分类：`08-FinanceInvestment`（金融投资 · 量化研究/风控）

## 和「因子建模师」怎么分工

| 环节 | 数模分析专家（本专家） | 因子建模师 |
|---|---|---|
| 想法 → 指标定义 | ✅ 七问 + 说明书 | 参考 |
| 公式转写、代码实现 | 只给规范 | ✅ 主责 |
| 检验矩阵设计 | ✅ 四层 + 判据 + 预算 | 执行检验 |
| IC/分层结果复核 | ✅ 按判据核对 | ✅ 主责产出 |
| 回撤归因与控制 | ✅ 主责 | 不涉及 |
| 组合风险预算 | ✅ 主责 | 不涉及 |

一句话：**本专家管"该测什么、测到什么算过、回撤怎么控"；因子建模师管"怎么算、算出什么数"。**

## 知识库结构

```
skills/indicator-research/
├── SKILL.md                          方法与三条铁律
├── references/
│   ├── 指标分析框架.md               七问、数学性质、逻辑审查 6 个否决项
│   ├── 检验方案设计.md               四层矩阵、NW-t、归因、样本外、多重检验、9 种失败模式
│   ├── 回撤方案设计.md               度量、七类归因、事前/事中/事后控制、五步设计、7 个陷阱
│   └── 参数与判据速查.md             阈值表、样本量、与因子建模师的分工
├── scripts/drawdown.py               回撤计算 + 四方案对比 + 自检
└── templates/
    ├── 指标说明书.md
    ├── 检验方案.md
    └── 回撤控制方案.md
```

## 回撤工具自检（本机实测）

```
[OK] MDD 计算 -0.2500 峰1 谷2
[OK] 最长水下期 3
[OK] Ulcer >= 0 / CDaR <= 0
[OK] 止损降低 MDD -0.827 -> -0.087
[OK] vol target 仓位在界内 [0.42,1.00]
[OK] 组合方案有限值
自检结果: 全部通过
```

一次合成数据上的方案对比（说明"控制有代价"）：

| 方案 | 总收益 | MDD | Calmar | Ulcer | 最长水下 |
|---|---|---|---|---|---|
| 无控制 | +41.8% | -30.3% | 0.41 | 11.06 | 247 |
| 固定止损 10% | +4.2% | -19.6% | 0.07 | 10.91 | 584 |
| 波动率目标 15% | +19.7% | -23.2% | 0.27 | 10.10 | 542 |
| 组合方案 | +6.1% | -9.8% | 0.20 | 7.84 | 552 |

**止损把 MDD 从 -30% 压到 -10%，收益从 42% 掉到 6%，Calmar 反而更差。** 这就是为什么不能只看回撤。

```bash
SK="C:/Users/Administrator/.workbuddy/plugins/marketplaces/my-experts/plugins/quant-indicator-analyst/skills/indicator-research"
python "$SK/scripts/drawdown.py" --selftest
python "$SK/scripts/drawdown.py" --csv nav.csv --col 1 --stop 0.10 --target-vol 0.15
```

## 使用示例

- 我有个指标想法，帮我拆成可检验的说明书并设计检验矩阵
- 这个策略最大回撤 30%，帮我还原归因并设计控制方案
- 检验到第几层了？哪些判据没过，下一步该测什么

## 头像

⚠️ `avatars/expert.png` **尚未生成**。`avatars/.gitkeep` 已占位，不影响校验与注册。可手动放入 PNG/JPG（512×512，≤500KB），或后续用 ImageGen 生成，推荐 prompt：

```
Professional cartoon-style illustration avatar, a quantitative model analyst,
wearing a dark shirt, standing before a validation matrix diagram and a drawdown
curve with shaded underwater areas, holding a calibrated ruler, focused analytical
expression, subtle grid and threshold lines in the background.
Bust shot, facing forward. Clean simple dark blue with gold accent background.
High quality, professional, natural.
```

生成时 `size` 用 `1024x1024`，输出到 `avatars/`，重命名为 `expert.png`。

## 安装与注册

```
C:/Users/Administrator/.workbuddy/plugins/marketplaces/my-experts/plugins/quant-indicator-analyst/
```

```bash
python scripts/validate_expert.py <expert-dir>
python scripts/register_expert.py <expert-dir> --session-id <session-id>
python scripts/package_expert.py <expert-dir> [output-dir]
```

## 免责声明

阈值均为经验起点，须用实际样本重新校准。本专家提供检验与风控方法，不构成投资建议；任何结论都依赖真实数据与执行假设。
