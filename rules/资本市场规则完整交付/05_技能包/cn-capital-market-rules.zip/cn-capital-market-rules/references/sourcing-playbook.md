# 规则检索与获取实操手册

配套文件：`assets/sources.json`（唯一权威来源清单，67 个入口 / 4 个等级）、`references/subjects.md`（主体→规则族映射）、`scripts/fetch_rules.py`、`scripts/probe_sources.py`。

## 标准工作流

1. **定主体与问题**：把用户的口语主体翻译成法定主体（例：「游资」→ 异常交易/程序化交易/账户出借/短线交易；「ETF」→ 产品，须查证监会 + 交易所 + 中国结算三处）。查 `subjects.md` 对应章节拿关键词。
2. **分级选源**：先按 `subjects.md` 的「必查来源」挑 3–5 个 `official` 来源 ID；跨层级问题（如股东减持）必须覆盖证监会规章 + 交易所自律规则 + 登记结算。官网受阻或需历史版本时，按下方「非官方替代路径」加 `secondary` 源。
3. **检索**：跑 `fetch_rules.py search <关键词> [--tier ...]` 生成检索 URL 与 `site:` 检索式，再用 WebSearch/WebFetch（或浏览器）拿具体规则详情页 URL。**不要凭记忆拼详情页 URL**。
4. **取全文**：`fetch_rules.py fetch <详情页URL> --out <目录>`，脚本抓正文、抽附件、下载 PDF/DOC、校验文件头、判定 `source_tier` 并输出 `metadata.json`。
5. **校验效力**：按「效力校验五步法」逐条过；二手来源自带的「现行有效」标记不能替代这一步。
6. **交付**：输出规则清单 + 来源等级 + URL + 抓取日期 + 效力状态 + 版本；明确区分一手与二手。

## 四层检索漏斗

| 层 | 手段 | 适用 |
|---|---|---|
| ① 站内权威库 | 证监会法规数据库 `csrc_neris_search`（浏览器打开）、规章库 `csrc_rules`、中基协 `amac_private` | 需要权威全文、文号、效力状态 |
| ② 限定域搜索 | `site:sse.com.cn/lawandrules/sselawsrules2025 {kw}`、`site:neris.csrc.gov.cn/falvfagui/rdqsHeader/mainbody {kw}` | 快速定位规则详情页 URL；搜索引擎收录了带 `secFutrsLawId` 的正文页 |
| ③ 栏目浏览/整包 | 规则总览、全部业务规则、制度规则汇编、现行自律规则汇编 | 需要穷举某主题全部规则，或一次性下载成包 |
| ④ 非官方替代 | 第三方法规库、开源法规数据集、律所/媒体解读、处罚文书库 | 官网被拦/页面下线、补历史版本与已废止文本、找规则名线索、查监管实证 |

搜索引擎结果只是**指路**，最终必须打开页面确认标题、文号、施行日期；④ 层内容还须回 ① 层核对。

### 按主体的检索式模板

```
散户      site:csrc.gov.cn 投资者适当性 管理办法 / site:szse.cn 投资者适当性 指引
游资      site:sse.com.cn 异常交易 程序化交易 实施细则 / site:cffex.com.cn 异常交易 管理办法
          site:jianweidata.com 异常交易 处罚        ← 处罚文书实证
机构      site:csrc.gov.cn 合格境外机构投资者 / site:sac.net.cn 网下投资者 管理规则
公募      site:csrc.gov.cn/csrc/c106256 公开募集证券投资基金 / site:fg.amac.org.cn 基金募集
私募      site:fg.amac.org.cn 私募投资基金 登记备案 效力状态 / site:gov.cn 私募投资基金监督管理条例
ETF       site:szse.cn 证券投资基金业务指引 流动性服务 / site:csindex.com.cn 指数编制方案
股东      site:csrc.gov.cn 上市公司股东减持股份管理暂行办法 / site:cninfo.com.cn 权益变动报告书
历史版本  site:lawtext.github.io {规则名}  / site:lawrefbook.github.io {法律名}
```

## 来源分级与非官方替代路径

### 四级采信规则

| tier | 数量 | 代表站点 | 可做什么 | 不能做什么 |
|---|---|---|---|---|
| `official` | 35 | 证监会法规库/规章库、沪深北交所、中基协/中证协、期货交易所、国务院/人大 | 直接作为规则原文与效力依据引用 | — |
| `quasi` | 12 | 最高法/裁判文书网、人民银行、金融监管总局、外汇局、巨潮资讯、中证指数、投保基金、中证金融 | 作事实依据：司法解释、指导案例、法定披露文件、指数编制方案、跨境与资金端规则 | 不能说成「该证券规则由本站发布」 |
| `secondary` | 14 | 北大法宝（含免费公众版）、威科先行、法律图书馆、法信、无讼、见微数据、LawRefBook、lawtext 在线文库 | 发现线索、补齐官网抓不到的全文、查历史/已废止版本、批量取上位法条文 | 不能替代一手效力判断；引用前必须回 `official` 核对标题/文号/版本 |
| `commentary` | 6 | 君合、中伦、证券时报、上证报、中证网、第一财经 | 理解新规变化、快速定位规则名、看监管表态 | **绝不能**作为规则原文或效力依据 |

脚本 `fetch_rules.py fetch` 按域名自动判定 `source_tier` 写入 `metadata.json`；`secondary` / `commentary` / 未登记 URL 会打警示。未登记站点一律按非一手处理。

### 什么时候切到非官方源（决策顺序）

1. 官网 412 / 403 / 安全验证 / SPA 空壳 → 先试浏览器；仍拿不到 → `site:` 搜 PDF 直链 → 再切 `secondary`。
2. 需要**已废止文本或历史版本** → 直接用 `lawtext_site`（2000+ 全国性法规 Markdown，含已废止，CI 自动更新）与 `lawrefbook_site`（554 部法律 / 459 部司法解释 / 755 部行政法规及部门规章，含《证券法》）。这两个是离线批量取条文最省事的入口。
3. 年代较早的规范性文件官网已下线 → `lawlib`（免费全文）、`pkulaw_free`（公众版按 CLI 引证码看全文）、`lawstar`。
4. 想快速搞清「新规改了什么 / 规则体系长什么样」 → `junhe`、`zhonglun` 等律所法评，或 `stcn` / `cnstock` 的政策快讯；只取规则名与文号线索，正文仍回官网。
5. 想看某类违规实际怎么被处罚（游资异常交易、股东违规减持） → `jianweidata`（证监监管处罚文书）、`wenshu`（裁判文书）、`itslaw`（案例法规检索）。
6. 需要上市公司侧配套材料（权益变动报告书、法律意见书、IPO 律师工作报告） → `cninfo` 巨潮资讯，属 `quasi`，可信度高于一般第三方。
7. ETF 跟踪指数的编制方案、成分调整规则 → `csindex` 中证指数（`quasi`）。

### 覆盖局限（必须如实告知）

- 开源法规数据集（`lawtext` / `LawRefBook`）原始文件来自国家法律法规数据库，**只覆盖法律、行政法规、司法解释、部门规章**，**不含交易所自律规则、中基协/中证协自律规则、期货交易所业务细则**。后者仍须回 `official` 或整包汇编。
- 商业法规库（`pkulaw` / `wkinfo`）多数内容需订阅；免费公众版有安全验证，脚本直连可能返回 567 验证页。
- 律所/媒体解读存在滞后与转述误差，本轮核实的「1+2 减持规则体系」即来自君合法评，其规则名与文号仍需回证监会法规库确认。
- 第三方站点的「现行有效」标签不等于官方效力状态；**最终的废止/修订判断只认 `official` 来源**。

### 使用纪律

- 允许交付里同时列 `official` 与 `secondary` 链接，但每条都要标 `tier`。
- 从 `secondary` 拿到全文后，用 `search "<规则名>" --tier official` 反查一手页面；查不到就在清单里写「一手未获取，全文来自 <站点>，效力待核验」。
- 绝不为凑齐来源把 `commentary` 文章冒充规则原文；解读材料单独列「参考材料」区。

## 实测踩坑（2026-11-09，65 个入口批量巡检结论）

1. **伪 200**：HTTP 200 不等于能拿到内容。`shfe`（305 字节）、`ine`（547 字节）、`amac_fg`（316 字节）、`flk`（552 字节）都是 SPA 空壳或跳转页；`nfra`（237 字节）、`pkulaw`（987 字节）、`lawlib`（984 字节）同理。**必须用浏览器打开**或改用具体子栏目。判断依据：字节数 < 1000 或 `<title>` 为空。
2. **412 / 403 / 567 拦截**：`dce`（大商所）、`czce`（郑商所）对脚本 GET 返回 412；金杜 403；北大法宝公众版 567 安全验证。降级顺序：加完整浏览器 UA/Referer → 浏览器（Playwright）渲染 → `site:` 搜索定位 PDF 直链 → 切 `secondary` 法规库 → 明确告知用户该入口需人工打开。
3. **路径改版**：上交所 2025 年把 `/lawandrules/sselawsrules/` 迁到 `/lawandrules/sselawsrules2025/`；引用旧链接会 404 或跳到导航页。发现 404 先跑 `probe_sources.py` 看是否整体改版。
4. **法规库是 SPA**：`neris.csrc.gov.cn/falvfagui/multipleFindController/indexJsp?secFutrsLawName={kw}` 返回约 7.5KB 空壳，结果列表由 AJAX 渲染，纯 HTTP 抓不到条目。⚠️ **正文页只有「文件名称/效力状态/文号/日期」字段区是服务端渲染**：71KB 是页面框架，转文本仅约 2.9KB，条文部分是 Vue 占位符（`{{secFutrsLawEntryPO.cntnt}}`、`没有符合条件的数据！`）；`navbarId=1/2/3` 与 `&body=` 各变体实测均如此，**纯 HTTP 拿不到条文全文**。取全文须走官方 PDF/公告页、gov.cn 公报、交易所详情页附件或浏览器渲染。用 `site:` 搜索找 ID 是为了拿字段与定位；脚本检测到 `{{...}}` 会写 `template_page` 并告警。
5. **深交所 title 无区分度**：多个深交所页面 `<title>` 都是「深交所主页」，但正文含完整规则列表。不要靠 title 判断页面类型，要看正文关键词。
6. **中基协双域名**：法规库在 `fg.amac.org.cn/governmentrules_3854/zcgz_zlgz/<主题>/`，主站在 `www.amac.org.cn`；主站「服务大厅」页面常附整套规则 PDF，是法规库找不到时的补充源。
7. **页面字段即效力证据**：证监会法规数据库**正文页**（`rdqsHeader/mainbody?secFutrsLawId=...`）与中基协详情页都带「文件名称 / 效力状态 / 失效日期 / 发文单位 / 文号 / 发文日期 / 实施日期」结构化字段。实测法规库正文页 71KB 仅为框架 + 模板，脚本能抓的是字段区（约 2.9KB 文本），**条文正文抓不到**；`fetch_rules.py` 会把这些字段解析到 `metadata.json` 的 `rule_fields` 与 `effectiveness`，并优先用「文件名称」而非通用 `<title>`（法规库 title 恒为「法规正文」）命名文件。**先看结构化效力状态，再看关键词扫描**。⚠️ 字段模板可能留空或被排版污染：实测中基协《私募投资基金登记备案办法》公告页「效力状态」为空、「实施日期」位置被塞进文号碎片。脚本已对日期/状态字段做合理性校验并置空；**留空不等于现行有效**，须另查废止公告、历史版本栏目或法规库。⚠️ 状态值还可能是「已被修改」（实测《公开募集证券投资基金管理人监督管理办法》在证监会法规库即如此标注，而中基协法规库标「现行有效」）；遇到冲突时**以证监会法规库为准并显式标注分歧**，不得静默选一个。
8. **Windows 路径坑**：给 Windows Python 脚本传路径必须用 `C:/Users/...` 或 `C:\\Users\\...`。传 Git Bash 的 `/c/Users/...` 会被解析成 `C:\c\Users\...`，文件静默落到错误盘位。
9. **附件链接多为相对路径/中文文件名**：必须 `urljoin` 解析并对 URL 中的中文做编码；保存时清理 Windows 非法字符 `<>:"/\|?*`。
10. **下载后必须校验文件头**：PDF 以 `%PDF` 开头、DOCX 以 `PK\x03\x04` 开头、老 DOC 以 `\xD0\xCF\x11\xE0` 开头。官网 WAF 有时会返回 200 + HTML 错误页却用 `.pdf` 文件名，仅看扩展名会拿到坏文件。
11. **GitHub 直连超时**：本机实测 `github.com` 上三个法规仓库均 15s 超时，但 GitHub Pages 站点（`lawtext.github.io` 23997B、`lawrefbook.github.io` 74584B）可正常访问。优先用 Pages 站点，需要 docx 原文时用 `gh` CLI 或代理。
12. **第三方站多为 SPA 首页**：`wkinfo`(5352B)、`chineselaw`(2362B)、`jianweidata`(3045B)、`lawsdata`(1675B) 返回的是框架页，脚本抓不到规则列表，需浏览器交互检索；但它们仍可作为 `site:` 检索域定位具体详情页。
13. **CFMMC 超时**：中国期货市场监控中心 `www.cfmmc.com` 实测读超时，标注在来源条目里，必要时用浏览器重试或搜索缓存。
14. **非官方来源也会被反爬**：不要假设「第三方站一定比官网好抓」；`pkulaw_free` 的安全验证页就是反例。
15. **证监会规章库分页与官方直链（批量下载首选）**：`fg.shtml` 是第 1 页，`fg_2.shtml` … `fg_5.shtml` 是第 2–5 页（页面内 `createPageHTML('page_div',5,1,'fg','shtml',89)`，共 89 条现行规章）。每条标题后紧跟「下载文字版 DOCX / 图片版 PDF」官方直链，按「标题链接 + 后两个下载链接」配对即可批量取原文，无需解析正文页。⚠️ `fg_1.shtml` 是新闻/公告页（约 221KB），**不是**规章列表，勿误用。
16. **官网批量下载会限流**：实测连续下载到第 13 个附件时出现 `ConnectionResetError 10054 远程主机强迫关闭连接`。批量脚本必须做：幂等（本地文件已存在且文件头正确即跳过）+ 3 次退避重试 + 每次请求间隔 0.5–1s + 失败项单独再重试一轮；单个请求异常不得中断整批。
17. **中基协法规库按主题分层**：部门规章·公募在 `/governmentrules_3854/zcgz_bmgz/bmgz_gmjj/`，自律规则·公募在 `/governmentrules_3854/zcgz_zlgz/zlgz_gmjj/`；同一规则在证监会法规库与中基协法规库可能给出不同「效力状态」（实测《公开募集证券投资基金管理人监督管理办法》：证监会「已被修改」vs 中基协「现行有效」），必须交叉核对并以证监会法规库为准。
18. **交易所规则详情页 URL 模式（实测可直接抓）**：上交所 `/lawandrules/sselawsrules2025/<板块>/<子类>/c/c_YYYYMMDD_编号.shtml`，例 `trade/universal/c/c_20250612_10781696.shtml`（程序化交易实施细则）、`fund/trading/c/c_20260617_10822565.shtml`（主动 ETF 指引）；深交所 `/lawrules/rule/<板块>/list/tYYYYMMDD_编号.html`，例 `fund/list/t20260617_621085.html`。详情页服务端渲染、带「时效性」字段与附件直链，比 JS 渲染的规则列表页更适合脚本抓取。用 `site:sse.com.cn/lawandrules <规则名>` 定位 `c_` 详情页，不要去啃列表页。
19. **规章库可按主题多标签分派复用**：一次抓 5 个分页、按各主体关键词给每条规章打多标签（如《证券登记结算管理办法》同时归游资/机构/ETF/股东），文件只下载一份放共享目录，清单按主体各引一次。实测 89 条中 47 条可覆盖六类主体，比逐主体重复抓取省一半以上请求。

## 效力校验五步法

1. **查现行有效标识**：`csrc_rules` 规章库按「现行有效」分组；证监会法规库正文页、中基协详情页看「效力状态」。**第三方库的时效性标签仅供参考**。
2. **查废止栏目**：上交所/深交所导航均有「已废止业务规则 / 规则废止公告 / 已废止规则文本」；期货交易所有「历史版本 / 交易所历史规则查询」。
3. **查正文里的废止条款**：正文结尾常见「《XXX》（文号）同时废止」或「本办法自 X 年 X 月 X 日起施行」。脚本会把这类句子放进 `validity_signals` 并打告警。
4. **查修订版本**：标题带「（2026 年修订）」「2025 年修订」的才是当前版；法规库同一 name 可能有多个版本页（例：减持办法已有 2024 发布版与 2025 修订版）。
5. **查上位法变更**：新《公司法》《证券法》修订会连带触发大批规则清理（证监会曾一次修改 21 部规章）。跨年度使用旧汇编或第三方全文时尤其要重查。

> 典型案例：用户举的《上市公司股东、董监高减持股份的若干规定》（证监会公告〔2017〕9 号）已于 2024-05-24 被证监会令第 224 号《上市公司股东减持股份管理暂行办法》废止，且后者已有 2025-03-27 证监会令第 227 号修订版。**任何「按用户给的规则名直接去找全文」的做法都必须先过这一步**；第三方站点上残留的 2017 版尤其多。

## 交付格式（规则清单）

每条规则输出以下字段，缺的写「未获取」，不要留空或猜：

| 字段 | 说明 |
|---|---|
| 主体 | 七类之一或交叉标注 |
| 规则名称 | 官方全称，含修订年份 |
| 文号 | 证监会令/公告号、中基协发〔〕号等；没有写「无」 |
| 发布机关 | 精确到机关，不写「监管部门」 |
| 效力层级 | 法律/行政法规/部门规章/规范性文件/自律规则/业务细则 |
| 发布与施行日期 | YYYY-MM-DD |
| 效力状态 | 现行有效 / 已废止 / 已修订（注明被谁取代）/ 待核验 |
| **来源等级** | official / quasi / secondary / commentary；非 official 必须注明「需核实原文」 |
| URL | 详情页或正文页，不用搜索结果页；二手来源另列一手核对链接（若有） |
| 本地文件 | 下载后的相对路径 + 文件类型 + 字节数 + 校验结果 |
| 抓取日期 | YYYY-MM-DD |

Markdown 表格或 CSV 均可；批量结果同时输出 `metadata.json` 便于回溯。解读类材料单独列「参考材料」，不混进规则清单。

## 脚本速查

```bash
PY="C:/Users/linmin/.workbuddy/binaries/python/versions/3.13.12/python.exe"
SK="C:/Users/linmin/.workbuddy/skills/cn-capital-market-rules"

# 列出来源 / 按组或等级筛
"$PY" "$SK/scripts/fetch_rules.py" list
"$PY" "$SK/scripts/fetch_rules.py" list --group 第三方法规库
"$PY" "$SK/scripts/fetch_rules.py" list --tier secondary

# 生成检索入口（关键词 → 各来源检索 URL 与 site: 检索式）
# 注意 --site 与 --tier 取交集，同时给时只输出同时满足的来源
"$PY" "$SK/scripts/fetch_rules.py" search "上市公司股东减持股份管理暂行办法"
"$PY" "$SK/scripts/fetch_rules.py" search "程序化交易" --site csrc_neris_search,sse_2025
"$PY" "$SK/scripts/fetch_rules.py" search "证券法" --tier official,secondary

# 抓详情页正文 + 附件 + 来源等级 + 时效信号
"$PY" "$SK/scripts/fetch_rules.py" fetch "https://neris.csrc.gov.cn/falvfagui/rdqsHeader/mainbody?navbarId=1&secFutrsLawId=9da8b0e7910e44c4a693073ee3b926c9" --out "C:/Users/linmin/rules_out"

# 入口健康巡检
"$PY" "$SK/scripts/probe_sources.py" --tier official --json "C:/Users/linmin/rules_out/probe_official.json"
"$PY" "$SK/scripts/probe_sources.py" --tier secondary --json "C:/Users/linmin/rules_out/probe_secondary.json"
```

脚本依赖 `requests`（本机托管 Python 3.13.12 已装 2.34.2）。默认已关闭证书校验（仅限公开只读页面）。

## 浏览器兜底（何时启用）

遇到以下任一情况，改用浏览器（本机已装 Playwright + Chromium；也可加载 `agent-browser` skill）：

- 来源条目 `probed.caveat` 标了「SPA / 空壳 / AJAX / 412 / 安全验证 / 超时」；
- 需要法规库「综合查询」结果列表，或需要按日期/效力层级筛选；
- 商业法规库（北大法宝、威科先行）需要交互检索或登录后才可见；
- 页面规则列表为「加载更多 / 分页 AJAX」，静态 HTML 只给第一页；
- 下载需要点击后才生成 PDF 链接。

浏览器路径只用于**读公开页面**，不要在监管官网提交表单、登录或上传任何数据。

## 红线

- 不编造规则名称、文号、施行日期；拿不到就写「未获取 / 待核验」。
- 允许使用官网以外的相关网站，但**必须标注来源等级**；`secondary` 的全文要回 `official` 核对，`commentary` 不得当规则原文。
- 不把搜索引擎摘要、律所解读、券商文章、开源数据集的「现行有效」标签当作效力依据。
- 不把「已废止」规则当作现行规则输出；不把旧版本当作最新版。
- 每条结论都要能追溯到 **URL + 来源等级 + 抓取日期**。
- 说明性材料（投服中心、协会解读、媒体报道）与有约束力的规则分开列。
