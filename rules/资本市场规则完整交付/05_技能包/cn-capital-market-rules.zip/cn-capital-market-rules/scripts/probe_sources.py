#!/usr/bin/env python3
"""官方规则入口健康巡检。

读取 assets/sources.json，并发 GET 每个来源，对比建库时的实测基线，
报告 HTTP 失败、WAF 拦截、SPA 空壳与疑似改版。官网改版后应先跑本脚本，
再更新 sources.json 的 probed 字段。

用法:
  probe_sources.py [--json report.json] [--group 交易所] [--workers 8] [--timeout 15]
"""
from __future__ import annotations

import argparse
import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

try:
    import requests
    import urllib3

    urllib3.disable_warnings()
except ImportError:  # pragma: no cover
    raise SystemExit("缺少 requests：请用托管 Python 运行，或 pip install requests")

ROOT = Path(__file__).resolve().parent.parent
SOURCES_FILE = ROOT / "assets" / "sources.json"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/120.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9",
}


def probe(source: dict, timeout: int) -> dict:
    url = source["url"]
    baseline = source.get("probed", {})
    headers = dict(HEADERS)
    parsed = urlparse(url)
    headers["Referer"] = f"{parsed.scheme}://{parsed.netloc}/"
    rec = {
        "id": source["id"], "name": source["name"], "group": source["group"],
        "url": url, "baseline": baseline, "checked_at": datetime.now().isoformat(timespec="seconds"),
    }
    try:
        r = requests.get(url, headers=headers, timeout=timeout, verify=False, allow_redirects=True)
        raw = r.content
        match = re.search(rb'charset\s*=\s*["\']?\s*([\w\-]+)', raw[:4096], re.I)
        enc = match.group(1).decode("ascii", "ignore") if match else (r.apparent_encoding or "utf-8")
        try:
            text = raw.decode(enc, errors="replace")
        except LookupError:
            text = raw.decode("utf-8", errors="replace")
        title_match = re.search(r"<title[^>]*>(.*?)</title>", text, re.S | re.I)
        title = re.sub(r"\s+", " ", title_match.group(1)).strip()[:60] if title_match else ""
        rec.update(status=r.status_code, bytes=len(raw), title=title, final_url=r.url)

        state, reasons = "OK", []
        if r.status_code in (401, 403, 412, 429):
            state = "BLOCKED"
            reasons.append(f"HTTP {r.status_code}：反爬/WAF 拦截，改用浏览器")
        elif r.status_code != 200:
            state = "FAIL"
            reasons.append(f"HTTP {r.status_code}")
        if len(raw) < 1000:
            reasons.append("响应 <1000 字节：疑似 SPA 空壳/跳转页，不能当列表页")
            if state == "OK":
                state = "EMPTY"
        if baseline:
            base_bytes = baseline.get("bytes") or 0
            if base_bytes > 1000 and len(raw) > 1000 and abs(len(raw) - base_bytes) / base_bytes > 0.6:
                reasons.append(f"字节数较基线 {base_bytes} 变化 {len(raw)}：疑似页面结构改版")
                if state == "OK":
                    state = "CHANGED"
            if baseline.get("title") and title and baseline["title"] not in title and title not in baseline["title"]:
                reasons.append(f"标题变化：{baseline['title']} → {title}")
                if state == "OK":
                    state = "CHANGED"
        if baseline.get("caveat") and state == "OK":
            reasons.append("已知限制：" + baseline["caveat"])
        rec.update(state=state, reasons=reasons)
    except Exception as exc:  # noqa: BLE001
        rec.update(state="FAIL", status="ERR", reasons=[f"{type(exc).__name__}: {str(exc)[:120]}"])
    return rec


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--json", help="把完整报告写入 JSON 文件")
    ap.add_argument("--group", help="只巡检指定分组，如 证监会 / 交易所 / 第三方法规库")
    ap.add_argument("--tier", help="按可信等级过滤，可逗号分隔：official / quasi / secondary / commentary")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--timeout", type=int, default=15)
    args = ap.parse_args()

    with SOURCES_FILE.open(encoding="utf-8") as fh:
        data = json.load(fh)
    tiers = set(args.tier.split(",")) if args.tier else None
    sources = [
        s for s in data["sources"]
        if (not args.group or args.group in s["group"])
        and (not tiers or s.get("tier") in tiers)
    ]

    results = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(probe, s, args.timeout): s["id"] for s in sources}
        for future in as_completed(futures):
            results.append(future.result())
    order = {s["id"]: i for i, s in enumerate(sources)}
    results.sort(key=lambda x: order[x["id"]])

    icon = {"OK": "OK", "CHANGED": "~~", "EMPTY": "..", "BLOCKED": "##", "FAIL": "XX"}
    for r in results:
        print(f"{icon.get(r['state'], '??'):<3} {str(r.get('status','')):>4} "
              f"{str(r.get('bytes','')):>8}  {r['id']:<22} {r.get('title','')[:26]:<28} {r['state']}")
        for reason in r["reasons"]:
            print(f"      - {reason}")

    summary = {state: sum(1 for r in results if r["state"] == state)
               for state in ("OK", "CHANGED", "EMPTY", "BLOCKED", "FAIL")}
    print("\n汇总:", "  ".join(f"{k}={v}" for k, v in summary.items()))
    print(f"基线实测日期: {data['probed_at']}；巡检时间: {datetime.now().isoformat(timespec='seconds')}")
    if args.json:
        report = {"summary": summary, "baseline_date": data["probed_at"], "results": results}
        Path(args.json).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"报告已写入: {Path(args.json).resolve()}")
    return 1 if summary["FAIL"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
