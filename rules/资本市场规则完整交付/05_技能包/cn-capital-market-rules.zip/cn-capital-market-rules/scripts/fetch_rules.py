#!/usr/bin/env python3
"""中国资本市场监管规则获取器。

子命令:
  list    列出分级来源清单（official / quasi / secondary / commentary）
  search  按关键词生成各来源的检索 URL / site: 检索式，支持 --tier 过滤
  fetch   抓取规则详情页正文与附件，下载并校验文件，输出元数据、来源等级与时效信号

仅访问公开只读页面；不提交表单、不登录、不执行下载内容。
依赖: requests (本机托管 Python 3.13.12 已安装)。
"""
from __future__ import annotations

import argparse
import hashlib
import html as html_mod
import json
import re
import sys
from datetime import datetime
from pathlib import Path
from urllib.parse import quote, urljoin, urlparse

try:
    import requests
    import urllib3

    urllib3.disable_warnings()
except ImportError:  # pragma: no cover
    sys.exit("缺少 requests：请用托管 Python 运行，或 pip install requests")

ROOT = Path(__file__).resolve().parent.parent
SOURCES_FILE = ROOT / "assets" / "sources.json"

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0 Safari/537.36"
)
HEADERS = {
    "User-Agent": UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9",
}

ATTACH_EXT = (".pdf", ".doc", ".docx", ".xls", ".xlsx", ".wps", ".zip", ".rar", ".7z", ".txt")
LINK_HINTS = ("files/", "download", "attach", "upload", "/P0")
INVALID_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')

VALIDITY_PATTERNS = [
    r"[^。；\n]{0,60}(?:同时废止|予以废止|已废止|宣布废止|停止执行)[^。；\n]{0,60}[。；]?",
    r"[^。；\n]{0,60}(?:失效日期|效力状态|现行有效)[^。；\n]{0,60}[。；]?",
    r"[^。；\n]{0,60}(?:自[^。；\n]{0,30}起施行|自公布之日起施行)[^。；\n]{0,60}[。；]?",
    r"[^。；\n]{0,60}(?:修订|修正|修改决定)[^。；\n]{0,60}[。；]?",
    r"[^。；\n]{0,40}(?:证监会令第\s*\d+\s*号|〔\d{4}〕\s*\d+\s*号)[^。；\n]{0,40}",
]


def load_sources() -> dict:
    with SOURCES_FILE.open(encoding="utf-8") as fh:
        return json.load(fh)


def classify_url(url: str, data: dict) -> dict:
    """按域名 + 最长路径前缀把任意 URL 映射到来源清单，判定可信等级。

    未登记的站点一律返回 unknown，按非一手处理，避免第三方内容被误采信。
    """
    parsed = urlparse(url)
    host = (parsed.hostname or "").lower()
    path = parsed.path.lower()
    best, best_score = None, -1
    for s in data["sources"]:
        src = urlparse(s["url"])
        src_host = (src.hostname or "").lower()
        if not src_host or not (host == src_host or host.endswith("." + src_host)):
            continue
        src_path = src.path.lower().rstrip("/")
        score = len(src_path) if (not src_path or path.startswith(src_path)) else -1
        if score > best_score:
            best, best_score = s, score
    if best:
        tier = best.get("tier", "official")
        return {
            "tier": tier, "source_id": best["id"], "source_name": best["name"],
            "tier_note": data.get("tiers", {}).get(tier, {}).get("rule", ""),
        }
    return {
        "tier": "unknown", "source_id": None, "source_name": None,
        "tier_note": "未登记在来源清单中：按非一手处理，须人工核实发布机关、文号与版本后方可引用",
    }


def decode_content(resp: requests.Response) -> str:
    raw = resp.content
    match = re.search(rb'charset\s*=\s*["\']?\s*([\w\-]+)', raw[:4096], re.I)
    enc = match.group(1).decode("ascii", "ignore") if match else (resp.apparent_encoding or "utf-8")
    try:
        return raw.decode(enc, errors="replace")
    except LookupError:
        return raw.decode("utf-8", errors="replace")


def get(url: str, timeout: int = 20, verify: bool = False, stream: bool = False):
    headers = dict(HEADERS)
    parsed = urlparse(url)
    headers["Referer"] = f"{parsed.scheme}://{parsed.netloc}/"
    return requests.get(
        url, headers=headers, timeout=timeout, verify=verify,
        allow_redirects=True, stream=stream,
    )


def html_to_text(page: str) -> str:
    text = re.sub(r"(?is)<(script|style|noscript)[^>]*>.*?</\1>", " ", page)
    text = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</tr>|</li>|</h[1-6]>", "\n", text)
    text = re.sub(r"(?s)<[^>]+>", " ", text)
    text = html_mod.unescape(text)
    text = re.sub(r"[ \t\u3000\xa0]+", " ", text)
    text = re.sub(r"\n\s*\n+", "\n\n", text)
    return text.strip()


def extract_title(page: str) -> str:
    for pattern in (r"<h1[^>]*>(.*?)</h1>", r"<title[^>]*>(.*?)</title>"):
        match = re.search(pattern, page, re.S | re.I)
        if match:
            title = html_to_text(match.group(1)).strip()
            if title:
                return re.sub(r"\s+", " ", title)[:160]
    return ""


FIELD_LABELS = (
    "文件名称", "效力状态", "失效日期", "发文单位", "发布机关", "文号",
    "发文日期", "实施日期", "施行日期", "时效性", "废止日期", "修订日期",
)


DATE_LABELS = {"发文日期", "实施日期", "施行日期", "失效日期", "废止日期", "修订日期"}
STATUS_LABELS = {"效力状态", "时效性"}


def clean_field_value(label: str, value: str) -> str:
    """过滤网页排版污染：日期位被塞进文号碎片、状态位被塞进导航文字等。"""
    if not value:
        return ""
    if label in DATE_LABELS and not re.match(r"^(19|20)\d{2}\s*[-年./]\s*\d{1,2}", value):
        return ""
    if label in STATUS_LABELS and not any(
        k in value for k in (
            "现行有效", "有效", "废止", "失效", "施行", "尚未生效",
            "已被修改", "已修改", "已修订", "部分失效", "已废止",
        )
    ):
        return ""
    return value


def extract_rule_fields(text: str) -> dict:
    """解析法规库/协会详情页常见的「标签 + 值」结构化字段。

    实测证监会法规库正文页与中基协详情页都带「文件名称/效力状态/失效日期/
    发文单位/文号/发文日期/实施日期」，比关键词扫描更可靠。
    """
    lines = [line.strip() for line in text.splitlines()]
    fields: dict[str, str] = {}
    for i, line in enumerate(lines):
        if line not in FIELD_LABELS:
            continue
        value = ""
        for nxt in lines[i + 1:i + 6]:
            if not nxt:
                continue
            if nxt in FIELD_LABELS:
                break
            value = nxt[:160]
            break
        value = clean_field_value(line, value)
        if value or line not in fields:
            fields[line] = value
    return fields


def extract_links(page: str, base_url: str, keyword: str | None = None) -> list[dict]:
    found: dict[str, dict] = {}
    for match in re.finditer(r"(?is)<a\b([^>]*)>(.*?)</a>", page):
        attrs, inner = match.group(1), match.group(2)
        href_match = re.search(r"href\s*=\s*([\"'])(.*?)\1", attrs, re.S)
        if not href_match:
            continue
        href = html_mod.unescape(href_match.group(2)).strip()
        if not href or href.startswith(("#", "javascript:", "mailto:")):
            continue
        label = re.sub(r"\s+", " ", html_to_text(inner)).strip()[:180]
        path = urlparse(href).path.lower()
        is_attach = path.endswith(ATTACH_EXT) or any(h in href.lower() for h in LINK_HINTS)
        if not is_attach:
            continue
        if keyword and keyword not in label and keyword not in href:
            # 无标题的附件链接保留，交由调用者判断
            if label:
                continue
        full = urljoin(base_url, href)
        if full not in found:
            found[full] = {"title": label or Path(path).name, "url": full}
    return list(found.values())


def sniff(data: bytes) -> str:
    if data.startswith(b"%PDF"):
        return "pdf"
    if data.startswith(b"PK\x03\x04"):
        return "docx_or_zip"
    if data.startswith(b"\xd0\xcf\x11\xe0"):
        return "doc_or_xls_ole"
    if data.startswith(b"Rar!"):
        return "rar"
    head = data[:512].lstrip().lower()
    if head.startswith(b"<!doctype") or head.startswith(b"<html") or b"<body" in head:
        return "html"
    return "unknown"


def safe_name(name: str, fallback: str = "rule") -> str:
    cleaned = INVALID_CHARS.sub("_", name).strip(" .")
    cleaned = re.sub(r"_+", "_", cleaned)
    return (cleaned or fallback)[:110]


def validity_signals(text: str, keyword: str | None = None) -> list[str]:
    signals: list[str] = []
    for pattern in VALIDITY_PATTERNS:
        for match in re.finditer(pattern, text):
            sentence = re.sub(r"\s+", " ", match.group(0)).strip()
            if 6 < len(sentence) < 240 and sentence not in signals:
                signals.append(sentence)
            if len(signals) >= 25:
                return signals
    return signals


def filter_sources(data: dict, group: str | None, tier: str | None) -> list[dict]:
    wanted = set(tier.split(",")) if tier else None
    return [
        s for s in data["sources"]
        if (not group or group in s["group"]) and (not wanted or s.get("tier") in wanted)
    ]


def cmd_list(args) -> int:
    data = load_sources()
    rows = filter_sources(data, args.group, args.tier)
    for s in rows:
        caveat = s.get("probed", {}).get("caveat", "")
        print(f"{s['id']:<22} [{s.get('tier','official'):<10}] {s['group']:<10} {s['name']}")
        print(f"{'':<22} {s['url']}")
        if caveat:
            print(f"{'':<22} ⚠ {caveat}")
    print(f"\n共 {len(rows)} 个来源；实测日期 {data['probed_at']}")
    for tier, info in data.get("tiers", {}).items():
        print(f"  {tier:<11} = {info['label']}")
    return 0


def build_search_query(source: dict, keyword: str) -> str:
    parsed = urlparse(source["url"])
    path = "/".join([p for p in parsed.path.split("/") if p][:2])
    default_scope = parsed.netloc + ("/" + path if path else "")
    scope = source.get("search_scope") or default_scope
    return f"site:{scope} {keyword}"


def cmd_search(args) -> int:
    data = load_sources()
    wanted = set(args.site.split(",")) if args.site else None
    results = []
    for s in filter_sources(data, None, args.tier):
        if wanted and s["id"] not in wanted:
            continue
        tier = s.get("tier", "official")
        entry = {
            "id": s["id"], "name": s["name"], "group": s["group"], "tier": tier,
            "url": s["url"], "search_query": build_search_query(s, args.keyword),
            "tier_note": data.get("tiers", {}).get(tier, {}).get("rule", ""),
        }
        # 只有明确的 URL 模板才作为可打开链接；search_hint 是给人看的提示文本
        if s.get("search_template"):
            entry["search_url"] = s["search_template"].replace("{kw}", quote(args.keyword))
        if s.get("search_hint"):
            entry["hint"] = s["search_hint"].replace("{kw}", args.keyword)
        entry["caveat"] = s.get("probed", {}).get("caveat", "")
        results.append(entry)
    if args.json:
        print(json.dumps({"keyword": args.keyword, "results": results}, ensure_ascii=False, indent=2))
        return 0
    for e in results:
        print(f"\n[{e['id']}] {e['name']}  <{e['tier']}>")
        print(f"  入口: {e['url']}")
        if e.get("search_url"):
            print(f"  检索: {e['search_url']}")
        print(f"  搜索式: {e['search_query']}")
        if e.get("hint"):
            print(f"  提示: {e['hint']}")
        if e["tier"] != "official":
            print(f"  采信: {e['tier_note']}")
        if e.get("caveat"):
            print(f"  ⚠ {e['caveat']}")
    print("\n提示：搜索式用于定位详情页 URL；非 official 来源仅作线索/补全文，结论须回一手官方核对。")
    return 0


def cmd_fetch(args) -> int:
    data = load_sources()
    src_info = classify_url(args.url, data)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    attach_dir = out / "attachments"
    if not args.no_download:
        attach_dir.mkdir(exist_ok=True)

    resp = get(args.url, timeout=args.timeout, verify=args.verify)
    page = decode_content(resp)
    text = html_to_text(page)
    rule_fields = extract_rule_fields(text)
    title = (
        (rule_fields.get("文件名称") or "").strip()
        or extract_title(page)
        or safe_name(urlparse(args.url).path.split("/")[-1])
        or "rule"
    )
    stem = safe_name(title)

    meta = {
        "fetched_at": datetime.now().isoformat(timespec="seconds"),
        "source_url": args.url,
        "final_url": resp.url,
        "http_status": resp.status_code,
        "content_bytes": len(resp.content),
        "title": title,
        "source_tier": src_info["tier"],
        "source_match": {"id": src_info["source_id"], "name": src_info["source_name"]},
        "tier_note": src_info["tier_note"],
        "rule_fields": rule_fields,
        "effectiveness": rule_fields.get("效力状态") or "页面未标注",
        "text_chars": len(text),
        "warnings": [],
    }
    if src_info["tier"] in ("secondary", "commentary"):
        meta["warnings"].append(
            f"非一手来源（{src_info['tier']}）：不得作为规则原文或效力依据直接引用，须回 official 来源核对"
        )
    elif src_info["tier"] == "unknown":
        meta["warnings"].append("该 URL 未登记在来源清单中：按非一手处理，须人工核实发布机关与版本")
    template_page = ("{{secFutrsLawEntryPO" in text or "{{entryInfo.entryVO" in text)
    meta["template_page"] = template_page
    if template_page:
        meta["warnings"].append(
            "证监会法规库 Vue 模板页：仅「文件名称/效力状态/文号/日期」字段区为服务端渲染，"
            "条文正文由 AJAX 加载（页面含 {{...cntnt}} 占位符），本次未取到条文；"
            "改用浏览器渲染、官方 PDF/公告页或 gov.cn 公报全文"
        )
    if resp.status_code != 200:
        meta["warnings"].append(f"HTTP {resp.status_code}，页面可能不可用")
    if len(resp.content) < 1000 or not title:
        meta["warnings"].append("疑似 SPA 空壳/跳转页（字节数过小或无标题），请改用浏览器打开")

    text_path = out / f"{stem}.txt"
    text_path.write_text(text, encoding="utf-8")
    meta["text_file"] = text_path.name

    signals = validity_signals(text, args.keyword)
    meta["validity_signals"] = signals
    eff = rule_fields.get("效力状态", "")
    if eff and any(k in eff for k in ("废止", "失效", "已修订", "已修改")):
        meta["warnings"].append(f"官方效力状态为「{eff}」，不得作为现行有效规则直接引用")
    if any("废止" in s or "失效" in s for s in signals):
        meta["warnings"].append("正文出现废止/失效表述，必须人工确认该规则是否仍现行有效")
    if re.search(r"（\s*20\d{2}\s*年\s*修订|20\d{2}\s*年修订版）", title):
        meta["warnings"].append("标题带修订年份：交付时须写明版本")

    links = extract_links(page, resp.url, args.keyword)
    meta["attachment_links_found"] = len(links)
    downloaded = []
    for link in links[: args.max_attachments]:
        item = dict(link)
        if args.no_download:
            downloaded.append(item)
            continue
        try:
            r = get(link["url"], timeout=args.timeout, verify=args.verify, stream=True)
            data = r.content
            kind = sniff(data)
            ext = Path(urlparse(link["url"]).path).suffix.lower() or ".bin"
            if kind == "html":
                item["ok"] = False
                item["warning"] = "返回 HTML 而非附件，可能被 WAF 拦截"
                downloaded.append(item)
                continue
            filename = safe_name(link["title"] or "attachment", "attachment")
            if not filename.lower().endswith(ext):
                filename += ext
            target = attach_dir / filename
            counter = 1
            while target.exists():
                target = attach_dir / f"{safe_name(filename, 'att')[:100]}_{counter}{ext}"
                counter += 1
            target.write_bytes(data)
            item.update(
                file=str(target.relative_to(out)).replace("\\", "/"),
                bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                sniffed=kind, ok=kind != "unknown",
            )
            if kind == "unknown":
                item["warning"] = "文件头无法识别，请人工打开确认完整性"
        except Exception as exc:  # noqa: BLE001
            item.update(ok=False, warning=f"{type(exc).__name__}: {str(exc)[:120]}")
        downloaded.append(item)
    meta["attachments"] = downloaded

    meta_path = out / "metadata.json"
    if meta_path.exists() and not args.overwrite_metadata:
        meta_path = out / f"metadata_{datetime.now().strftime('%H%M%S')}.json"
    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"标题: {title}")
    print(f"来源等级: {src_info['tier']}"
          + (f" ({src_info['source_id']})" if src_info["source_id"] else "（未登记来源）"))
    print(f"状态: {resp.status_code} / {len(resp.content)} bytes / 正文 {len(text)} 字")
    if rule_fields:
        print("官方字段: " + "; ".join(f"{k}={v or '空'}" for k, v in rule_fields.items()))
    print(f"正文: {text_path}")
    print(f"附件: {len(downloaded)} 个（发现 {len(links)} 个链接）")
    for item in downloaded:
        mark = "OK" if item.get("ok") else "!!"
        print(f"  {mark} {item.get('title', '')[:60]} -> {item.get('file', item.get('warning', '未下载'))}")
    print(f"时效信号: {len(signals)} 条")
    for s in signals[:8]:
        print(f"  · {s[:150]}")
    for w in meta["warnings"]:
        print(f"⚠ {w}")
    print(f"元数据: {meta_path}")
    return 0 if resp.status_code == 200 else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="cmd", required=True)

    TIER_HELP = "按可信等级过滤，可逗号分隔：official / quasi / secondary / commentary"
    p_list = sub.add_parser("list", help="列出来源清单")
    p_list.add_argument("--group", help="按分组过滤，如 证监会 / 交易所 / 第三方法规库")
    p_list.add_argument("--tier", help=TIER_HELP)
    p_list.set_defaults(func=cmd_list)

    p_search = sub.add_parser("search", help="生成检索入口")
    p_search.add_argument("keyword", help="检索关键词或规则名")
    p_search.add_argument("--site", help="只输出指定来源 ID，逗号分隔")
    p_search.add_argument("--tier", help=TIER_HELP)
    p_search.add_argument("--json", action="store_true", help="输出 JSON")
    p_search.set_defaults(func=cmd_search)

    p_fetch = sub.add_parser("fetch", help="抓取规则详情页")
    p_fetch.add_argument("url", help="规则详情页或正文页 URL")
    p_fetch.add_argument("--out", default="rules_out", help="输出目录（Windows 用 C:/... 形式）")
    p_fetch.add_argument("--keyword", help="附件过滤关键词；不传则保留全部附件")
    p_fetch.add_argument("--max-attachments", type=int, default=20)
    p_fetch.add_argument("--no-download", action="store_true", help="只列附件链接不下载")
    p_fetch.add_argument("--timeout", type=int, default=20)
    p_fetch.add_argument("--verify", action="store_true", help="开启 TLS 证书校验（默认关闭以兼容政府站点）")
    p_fetch.add_argument("--overwrite-metadata", action="store_true")
    p_fetch.set_defaults(func=cmd_fetch)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
