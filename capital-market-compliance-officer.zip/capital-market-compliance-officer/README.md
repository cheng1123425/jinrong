# 合规性检验官 · Capital Market Compliance Officer

依据「中国资本市场监管规则完整交付包」（2026-11-09 抓取）对项目产出物做合规检验的 Agent 型专家。

## 类型

Agent 型（单个 AI 专家）｜行业分类：`11-SecurityCompliance`（法务安全 · 合规审查）

> 分类理由：专家的核心输出物是**合规检验报告**、核心能力是**合规判定与效力校验**，服务对象是做合规自查的项目方，而非投资分析或收益预测。虽面向资本市场，但按「主要输出物 / 最核心能力」优先级应归入合规审查类，而非 `08-FinanceInvestment`。

## 装载的规则库

| 项 | 值 |
|---|---|
| 规则全文 | 91 份 Markdown，4016 条条文 |
| 主体 | 散户 13 / 游资 11 / 机构 16 / 私募 10 / ETF 9 / 股东 12 / 公募基金 20 |
| 来源 | 证监会规章库与法规数据库、交易所、中基协/中证协、gov.cn 等官方原文；抓取日期 2026-11-09 |
| 元数据 | 文号、效力层级、发布/施行日期、效力状态、来源 URL、sha256（见 `清单与元数据/`） |
| 时效提示 | 8 条效力陷阱 + 未获取/待补清单 |

规则库以**离线副本**形式装在专家包内，不依赖临时工作区路径：

```
skills/capital-market-compliance/
├── SKILL.md                        合规检验方法与三条红线
├── references/
│   ├── rules/                      91 份规则全文（7 类主体分目录）
│   ├── catalog.json                机器可读规则目录
│   ├── 规则速查索引.md             主体→规则族→效力标记
│   ├── 合规红线清单.md             行为→规则映射 + 效力陷阱 + 依据不足清单
│   ├── 00_时效与效力提示.md        交付包原始时效提示
│   ├── 清单与元数据/               清单 / manifest / metadata / 转换报告
│   └── 合规检验报告模板.md
└── scripts/search_rules.py         stat / list / search / article 条文检索器
```

> 交付包中的 `02_`/`03_` 官方原件（PDF/DOCX，约 25MB）为同一批规则的另一格式，未随包复制；其文件清单、URL、文号与 sha256 已收录在 `references/清单与元数据/`。需要引用扫描件或存档时，按清单中的 `source_url` 回官网获取。

## 能力边界

- **做**：合规检验、规则查询、效力核对、条文取回、带证据的五级结论（通过 / 有条件通过 / 不通过 / 待核验 / 不适用）。
- **不做**：投资建议、行情分析、收益预测、策略优化、法律意见出具，以及任何规避监管的方案设计。
- **已知依据不足**：《证券法》全文（短线交易、内幕交易、操纵市场法定条款）、程序化交易管理规定（试行）正文、沪深交易所异常交易细则、中国结算细则、期货交易所异常交易细则、基金投顾规定。命中这些领域的结论一律标「待核验·依据不足」。

## 使用示例

- 检验这个套利策略是否符合资本市场规则，出具带条文引用的合规检验报告
- 这个程序化交易行动需要履行哪些报告义务？会不会被认定为高频交易
- 查一下股东减持相关规则现在是否现行有效，有哪些版本陷阱

```bash
python skills/capital-market-compliance/scripts/search_rules.py stat
python skills/capital-market-compliance/scripts/search_rules.py search "高频交易" --subject 游资
```

## 头像

⚠️ `avatars/expert.png` **尚未生成**（本次跳过了图像生成）。`avatars/.gitkeep` 已占位，专家包可正常校验与注册，但专家卡片暂无头像。可手动放入一张 PNG/JPG（512×512，≤500KB），或后续用 ImageGen 生成，推荐 prompt：

```
Professional cartoon-style illustration avatar, a meticulous capital-market compliance
inspector, wearing a neat dark navy suit with a subtle official badge, holding a bound
rulebook and a magnifying glass over pages of regulatory articles, calm stern impartial
expression with sharp attentive eyes, balanced scales of justice, compliance checklists
and documents with article numbers floating softly in the background.
Bust shot, facing forward. Clean simple dark grey-blue toned background.
High quality, professional, natural.
```

生成时 `size` 用 `1024x1024`，输出到 `avatars/`，再重命名为 `expert.png`。

## 安装与注册

专家目录：

```
C:/Users/Administrator/.workbuddy/plugins/marketplaces/my-experts/plugins/capital-market-compliance-officer/
```

注册后可在 WorkBuddy【专家中心 - 我的专家】中看到：

```bash
python scripts/validate_expert.py <expert-dir>
python scripts/register_expert.py <expert-dir> --session-id <session-id>
python scripts/package_expert.py <expert-dir> [output-dir]
```

## 免责声明

规则库为 2026-11-09 的本地快照，规则可能已修订或废止。专家出具的报告仅供项目内部合规自查，不构成法律意见、不构成监管机构认定，正式决策前须按各规则 `source_url` 回官方发布页核验现行有效版本。
