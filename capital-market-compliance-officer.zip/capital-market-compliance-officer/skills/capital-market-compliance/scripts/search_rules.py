#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
中国资本市场监管规则库 · 条文检索器

供「合规性检验官」在出具判定前精确取回规则原文，禁止凭记忆引用条文。

用法（脚本自带 references/ 定位，可从任意工作目录调用）：
  python search_rules.py list [--subject 散户] [--json]
  python search_rules.py search "程序化交易" [--subject 游资] [--limit 20]
  python search_rules.py article "减持股份管理暂行办法" [第X条] [--full]
  python search_rules.py stat

输出中的每条命中都带：规则名 / 文号 / 效力状态 / 主体 / 条号 / 相对文件路径 / 原文摘录。
引用条文前必须核对 frontmatter 的 effect 字段，效力存疑者标「待核验」。
"""

import argparse
import json
import re
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent / "references"
CATALOG = BASE / "catalog.json"
RULES = BASE / "rules"

ARTICLE_RE = re.compile(r"^###\s*(第[一二三四五六七八九十百千零〇\d]+条.*)$", re.M)
CHAPTER_RE = re.compile(r"^##\s*(第[一二三四五六七八九十百千零〇\d]+章.*)$", re.M)


def load_catalog():
    with CATALOG.open(encoding="utf-8") as f:
        return json.load(f)


def read_rule(entry):
    p = BASE / entry["file"]
    if not p.exists():
        return ""
    return p.read_text(encoding="utf-8", errors="replace")


def split_articles(text):
    """按 `### 第X条` 切块，返回 [(条标题, 条正文, 所属章)]。"""
    # 去掉 frontmatter
    body = re.sub(r"^---\n.*?\n---\n", "", text, count=1, flags=re.S)
    marks = list(ARTICLE_RE.finditer(body))
    chapters = list(CHAPTER_RE.finditer(body))
    out = []
    for i, m in enumerate(marks):
        start = m.end()
        end = marks[i + 1].start() if i + 1 < len(marks) else len(body)
        chunk = body[start:end].strip()
        ch = ""
        for c in chapters:
            if c.start() < m.start():
                ch = c.group(1).strip()
            else:
                break
        out.append((m.group(1).strip(), chunk, ch))
    return out


def cmd_stat(args):
    cat = load_catalog()
    from collections import Counter
    by_subject = Counter(c["subject"] for c in cat)
    total = sum(int(c["articles"]) for c in cat if str(c["articles"]).isdigit())
    print(f"规则文件: {len(cat)} 份 | 条文: {total} 条 | 抓取日期: {cat[0].get('fetched_at','')}")
    for k, v in sorted(by_subject.items()):
        print(f"  {k}: {v} 份")
    print("\n效力状态分布:")
    for k, v in Counter(c["effect"][:24] for c in cat).most_common():
        print(f"  {k} ... : {v}")


def cmd_list(args):
    cat = load_catalog()
    if args.subject:
        cat = [c for c in cat if args.subject in c["subject"]]
    if args.json:
        print(json.dumps(cat, ensure_ascii=False, indent=2))
        return
    print(f"共 {len(cat)} 份规则\n")
    for c in cat:
        print(f"[{c['subject']}] {c['title']}")
        print(f"  文号={c['doc_no']} | 层级={c['level']} | 条数={c['articles']} | 发布={c['publish_date']}")
        print(f"  效力={c['effect']}")
        print(f"  来源={c['source_tier']} {c['source_url']}")
        print(f"  文件={c['file']}\n")


def cmd_search(args):
    cat = load_catalog()
    kw = args.keyword
    if args.subject:
        cat = [c for c in cat if args.subject in c["subject"]]
    hits = 0
    for c in cat:
        text = read_rule(c)
        for title, chunk, ch in split_articles(text):
            if kw in title or kw in chunk:
                hits += 1
                if hits > args.limit:
                    print(f"\n... 命中超过 {args.limit} 条，已截断。请缩小关键词或加 --subject / --limit。")
                    return
                snip = chunk.replace("\n", " ")
                pos = snip.find(kw)
                s = max(0, pos - 60)
                excerpt = ("…" if s > 0 else "") + snip[s:s + 220] + ("…" if s + 220 < len(snip) else "")
                print(f"【{c['title']}】{title}" + (f"（{ch}）" if ch else ""))
                print(f"  主体={c['subject']} | 文号={c['doc_no']} | 效力={c['effect']}")
                print(f"  文件={c['file']}")
                print(f"  原文摘录: {excerpt}\n")
    if hits == 0:
        print(f"未检索到「{kw}」。可换同义表述（如「报备/报告」「异常交易」「操纵」），或先 list 确认规则是否在库。")
        print("注意：本库 91 份规则并未覆盖全部市场监管规则，《证券法》全文、交易所异常交易细则等属「未获取」，见 00_时效与效力提示.md。")
    else:
        print(f"命中 {hits} 处。引用前务必核对上述「效力」字段与 00_时效与效力提示.md 的时效陷阱。")


def cmd_article(args):
    cat = load_catalog()
    matched = [c for c in cat if args.rule in c["title"] or args.rule in c["file"]]
    if not matched:
        print(f"未找到规则「{args.rule}」，用 list 查看全部规则名。")
        return
    for c in matched:
        text = read_rule(c)
        print(f"===== {c['title']} =====")
        print(f"文号={c['doc_no']} | 效力={c['effect']} | 发布={c['publish_date']} | 机关={c['issuer']}")
        print(f"来源={c['source_url']} | 文件={c['file']}\n")
        arts = split_articles(text)
        if args.article and not args.full:
            found = [a for a in arts if args.article in a[0]]
            if not found:
                print(f"该规则中未找到「{args.article}」，共 {len(arts)} 条。可加 --full 看全文。")
            for t, chunk, ch in found:
                print(f"{ch}\n{t}\n{chunk}\n")
        elif args.full:
            print(re.sub(r"^---\n.*?\n---\n", "", text, count=1, flags=re.S))
        else:
            for t, chunk, ch in arts[:12]:
                print(f"{t}（{ch}）: {chunk[:120].replace(chr(10),' ')}…")
            print(f"\n共 {len(arts)} 条。用 `article \"{args.rule}\" 第X条` 取指定条文，或 --full 取全文。")
        print()


def main():
    ap = argparse.ArgumentParser(description="中国资本市场监管规则库检索器")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("stat", help="库统计")
    p.set_defaults(func=cmd_stat)

    p = sub.add_parser("list", help="列出规则")
    p.add_argument("--subject", help="按主体过滤：散户/游资/机构/私募/ETF/股东/公募基金")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_list)

    p = sub.add_parser("search", help="全文检索条文")
    p.add_argument("keyword", help="关键词")
    p.add_argument("--subject", help="按主体过滤")
    p.add_argument("--limit", type=int, default=20)
    p.set_defaults(func=cmd_search)

    p = sub.add_parser("article", help="取规则全文或指定条文")
    p.add_argument("rule", help="规则名关键词")
    p.add_argument("article", nargs="?", help="条号，如 第十二条")
    p.add_argument("--full", action="store_true", help="输出全文")
    p.set_defaults(func=cmd_article)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
