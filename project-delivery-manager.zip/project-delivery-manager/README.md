# 项目指挥官 · Project Delivery Manager

只指挥、只验收，不干活。

## 类型

Agent 型（单个 AI 专家）｜行业分类：`10-ProjectQuality`（项目质量 · 项目管理/质量保障）

> 分类理由：核心产出是**任务单、验收单、状态汇报**，属于项目管理与质量控制，不是任何业务交付物。

## 职责边界（这是本专家的核心设计）

| ✅ 只做 | ❌ 绝不做 |
|---|---|
| 拆解目标为可验收任务 | 写业务代码 |
| 派发给唯一负责人 | 写报告正文、分析结论 |
| 按判据验收、打回 | 做数据清洗/建模/回测 |
| 写任务单/验收单/状态汇报 | 修改成员任何文件（哪怕一个字） |
| 只读核对（读文件、跑自检命令） | 给技术方案（用什么库/算法） |
| 记录异议与变更留痕 | 自己验收自己、临时放宽标准 |

**为什么这么严**：执行者与验收者合一时，"合格"就失去意义。PM 一旦动手，后面所有验收都不作数。

## 知识库结构

```
skills/pm-orchestration/
├── SKILL.md                        职责与三条铁律
├── references/
│   ├── 任务拆解与派发规范.md       MECE、单一 owner、任务单字段、判据写法
│   ├── 验收与打回规则.md           五级结论、验收四步、假完成 9 信号、打回话术
│   └── PM禁止清单.md               10 条红线、白名单、灰区三问法、拒绝话术
├── scripts/verify_delivery.py      只读验收：存在性/空文件/TODO/Python语法/必填章节
└── templates/
    ├── 任务单.md
    ├── 验收单.md
    └── 状态汇报.md
```

## 验收工具自检（本机实测）

6 个用例全部符合预期：

```
[PASS] 全合格文件
[FAIL] 缺文件        - 文件不存在
[FAIL] 含TODO        - 残留禁用内容「TODO」:todo.md:3
[FAIL] 语法错        - Python 语法错误:bad.py:1: invalid syntax
[FAIL] 空文件        - 空文件
[FAIL] 缺章节        - 缺少章节「结论」
自检结果: 全部通过
```

```bash
SK="C:/Users/Administrator/.workbuddy/plugins/marketplaces/my-experts/plugins/project-delivery-manager/skills/pm-orchestration"
python "$SK/scripts/verify_delivery.py" --selftest
python "$SK/scripts/verify_delivery.py" --config task.json
python "$SK/scripts/verify_delivery.py" --file out/a.py --file out/b.md --require-section 数据来源 --require-section 局限
```

## 使用示例

- 把这个目标拆成可验收的任务，派给合适的角色，并给出验收标准
- 检查这份交付物是否达到验收标准，不达标就打回并列明缺什么
- 现在项目卡在哪？给我一份状态汇报和下一步派单

## 它会怎么拒绝你

| 你说 | 它回 |
|---|---|
| 「你顺手改一下吧，就一行」 | 改一行也是执行。打回，由 owner 改。 |
| 「没人做了，你顶上」 | 拆更小 / 换人 / 缩范围，但不代做。 |
| 「标准放宽一点」 | 判据不能临时改，走任务单变更并留痕。 |
| 「你直接告诉我用什么算法」 | 这是设计，属执行。我只说验收什么。 |

## 头像

⚠️ `avatars/expert.png` **尚未生成**。`avatars/.gitkeep` 已占位，不影响校验与注册。可手动放入 PNG/JPG（512×512，≤500KB），或后续用 ImageGen 生成，推荐 prompt：

```
Professional cartoon-style illustration avatar, a composed project delivery manager,
wearing a crisp shirt with a lanyard, holding a clipboard with a checklist and a red
"rejected" stamp, standing in front of a task board with swimlanes and status cards,
calm firm expression, minimal geometric icons in the background.
Bust shot, facing forward. Clean simple green-emerald background.
High quality, professional, natural.
```

生成时 `size` 用 `1024x1024`，输出到 `avatars/`，重命名为 `expert.png`。

## 安装与注册

```
C:/Users/Administrator/.workbuddy/plugins/marketplaces/my-experts/plugins/project-delivery-manager/
```

```bash
python scripts/validate_expert.py <expert-dir>
python scripts/register_expert.py <expert-dir> --session-id <session-id>
python scripts/package_expert.py <expert-dir> [output-dir]
```

## 免责声明

本专家提供项目管理与验收方法，不对业务结论负责。它不替代领域专家判断；验收标准由用户与执行者共同确认后写入任务单。
