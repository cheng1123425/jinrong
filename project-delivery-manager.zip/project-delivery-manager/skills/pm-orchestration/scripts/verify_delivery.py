#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
交付验收工具（PM 专用，只读校验）

只做核对，不修改任何交付物：检查存在性、空文件、禁用残留、Python 语法、报告必填章节。
判定结果只有 PASS / FAIL，不输出"还不错"这类评价。

用法：
  python verify_delivery.py --selftest
  python verify_delivery.py --config task.json
  python verify_delivery.py --file out/a.py --file out/b.md --require-section 数据来源 --require-section 局限

task.json 格式：
{
  "task": "T-01",
  "deliverables": [
    {"path": "out/a.py", "type": "py"},
    {"path": "out/b.md", "type": "md", "sections": ["数据来源", "方法", "结果", "局限"]}
  ],
  "forbid": ["TODO", "待补", "此处省略"]
}
"""

import argparse
import json
import os
import sys
import tempfile

DEFAULT_FORBID = ["TODO", "[待补]", "待补", "此处省略", "pass  # 后续"]


def _read_text(p):
    try:
        return open(p, encoding="utf-8", errors="replace").read()
    except Exception:
        return ""


def check_one(d, forbid):
    issues = []
    p = d["path"]
    if not os.path.exists(p):
        return [f"文件不存在: {p}"], None
    if os.path.isdir(p):
        return [f"是目录不是文件: {p}"], None
    if os.path.getsize(p) == 0:
        issues.append(f"空文件: {p}")

    text = _read_text(p) if os.path.getsize(p) < 20 * 1024 * 1024 else ""

    for pat in forbid:
        if text and pat in text:
            line = next((i + 1 for i, l in enumerate(text.splitlines()) if pat in l), 0)
            issues.append(f"残留禁用内容「{pat}」: {p}:{line}")

    if p.lower().endswith(".py"):
        try:
            compile(text, p, "exec")
        except SyntaxError as e:
            issues.append(f"Python 语法错误: {p}:{e.lineno}: {e.msg}")

    for sec in d.get("sections", []):
        if sec not in text:
            issues.append(f"缺少章节「{sec}」: {p}")

    return issues, text


def run(config):
    forbid = config.get("forbid", DEFAULT_FORBID)
    dels = config.get("deliverables", [])
    print(f"验收任务: {config.get('task', '(未命名)')} | 交付物 {len(dels)} 项\n")
    all_issues = []
    for d in dels:
        iss, _ = check_one(d, forbid)
        status = "PASS" if not iss else "FAIL"
        print(f"[{status}] {d['path']}")
        for i in iss:
            print(f"        - {i}")
        all_issues.extend(iss)
    print()
    if all_issues:
        print(f"结论：FAIL（{len(all_issues)} 项不符合）→ 打回，逐条补齐后重交")
        return False
    print("结论：PASS（全部判据满足）")
    return True


def selftest():
    ok = True
    tmp = tempfile.mkdtemp(prefix="pmverify_")

    def w(name, content):
        p = os.path.join(tmp, name)
        os.makedirs(tmp, exist_ok=True)
        open(p, "w", encoding="utf-8").write(content)
        return p

    good_py = w("good.py", "def f(x):\n    return x * 2\n")
    good_md = w("good.md", "# 报告\n## 数据来源\nx\n## 方法\ny\n## 结果\nz\n## 局限\nw\n")
    todo_md = w("todo.md", "# 报告\n## 数据来源\nTODO\n## 方法\n\n## 结果\n\n## 局限\n\n")
    bad_py = w("bad.py", "def f(:\n  return 1\n")
    empty_md = w("empty.md", "")

    cases = [
        ("全合格", {"task": "T1", "deliverables": [
            {"path": good_py, "type": "py"},
            {"path": good_md, "type": "md", "sections": ["数据来源", "方法", "结果", "局限"]}]}, True),
        ("缺文件", {"task": "T2", "deliverables": [{"path": os.path.join(tmp, "nope.md")}]}, False),
        ("含TODO", {"task": "T3", "deliverables": [{"path": todo_md, "sections": ["数据来源"]}]}, False),
        ("语法错", {"task": "T4", "deliverables": [{"path": bad_py}]}, False),
        ("空文件", {"task": "T5", "deliverables": [{"path": empty_md}]}, False),
        ("缺章节", {"task": "T6", "deliverables": [{"path": good_md, "sections": ["结论"]}]}, False),
    ]
    for name, cfg, expect in cases:
        print(f"\n--- 自检用例：{name}（预期 {'PASS' if expect else 'FAIL'}）---")
        got = run(cfg)
        ok &= (got == expect)
    print("\n自检结果:", "全部通过 ✅" if ok else "存在失败 ❌")
    return ok


def main():
    ap = argparse.ArgumentParser(description="交付验收工具（只读）")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--config", help="任务单 JSON 路径")
    ap.add_argument("--file", action="append", default=[], help="交付物路径，可多次")
    ap.add_argument("--require-section", action="append", default=[], help="报告必须包含的章节，可多次")
    ap.add_argument("--forbid", action="append", default=[], help="额外禁用词")
    args = ap.parse_args()

    if args.selftest:
        sys.exit(0 if selftest() else 1)

    if args.config:
        cfg = json.load(open(args.config, encoding="utf-8"))
        if args.forbid:
            cfg["forbid"] = list(cfg.get("forbid", DEFAULT_FORBID)) + args.forbid
    elif args.file:
        cfg = {"task": "CLI", "deliverables": [
            {"path": f, "sections": args.require_section} for f in args.file],
            "forbid": DEFAULT_FORBID + args.forbid}
    else:
        ap.print_help()
        sys.exit(1)

    sys.exit(0 if run(cfg) else 1)


if __name__ == "__main__":
    main()
