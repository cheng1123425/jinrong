# 量纲统一数据分析师 · Data Normalization Analyst

让不同单位、不同量级、不同分布的数据变得可比。先诊断，再选方法，全程防泄漏。

## 类型

Agent 型（单个 AI 专家）｜行业分类：`04-DataAI`（数据智能 · 数据预处理/特征工程）

> 分类理由：核心输出物是**预处理方案与标准化后的数据**，属于数据分析方法层；服务对象是建模与分析流程，不直接产出业务决策。

## 能力范围

| 做 | 不做 |
|---|---|
| 逐列诊断：缺失、偏度、峰度、离群、有界、稀疏 | 替用户断言分布而不看数据 |
| 11 种缩放/分布变换的选型与参数 | 只丢一个 `StandardScaler()` 就完事 |
| 指标正向化 + 熵权/TOPSIS 前的归一化 | 建模、调参、预测 |
| 面板数据：截面 / 时序 / 分组标准化 | 全样本标准化后回测（会明确指认为泄漏） |
| 中性化与标准化的区分、去极值顺序 | 在单位口径不明时硬算 |
| fit/transform 分离与滚动方案 | 忽略常量列 / 缺失导致的 inf |

## 方法覆盖

`z-score`、`Min-Max`、`MaxAbs`、`Robust`、`秩（百分位）`、`rank-Gauss`、`log1p`、`Box-Cox`、`Yeo-Johnson`、`L2 归一化`、`不处理`。

## 知识库结构

```
skills/data-harmonization/
├── SKILL.md                          方法与三条铁律
├── references/
│   ├── 量纲处理手册.md               11 种方法全谱 + 正向化 + 熵权/TOPSIS + 常见错误
│   ├── 方法选择与场景对照表.md       按模型/数据/目标选型、决策流程、反例
│   ├── 面板与金融数据要点.md         截面 vs 时序、分组、中性化、前视偏差、单位统一
│   └── 实现速查.md                   纯 numpy 实现 + sklearn/pandas 模板 + 上线注意
├── scripts/harmonize.py              11 种方法、fit/transform 分离、诊断建议、CSV 批处理、自检
└── templates/数据处理方案模板.md
```

## 工具自检结果（本机实测）

```
[OK] zscore 均值≈0            mean=5.33e-18
[OK] zscore 标准差≈1          std=1.000000
[OK] minmax 落在[0,1]         [0.000,1.000]
[OK] robust 中位数≈0          median=0.00e+00
[OK] rank 均匀且∈(0,1)        mean=0.500
[OK] rank_gauss 近似标准正态  mean=-0.000 std=0.999 skew=-0.000
[OK] boxcox 降偏度            1.54 -> -0.01
[OK] zscore 逆变换还原
[OK] 测试集用训练参数         train=0.000 test=0.019
[OK] 常量列 5 种方法均无 inf/nan
自检结果: 全部通过
```

依存：**numpy + scipy**（本机已具备）。无需 sklearn / pandas。

```bash
SK="C:/Users/Administrator/.workbuddy/plugins/marketplaces/my-experts/plugins/data-normalization-analyst/skills/data-harmonization"
python "$SK/scripts/harmonize.py" selftest
python "$SK/scripts/harmonize.py" report --csv data.csv
python "$SK/scripts/harmonize.py" transform --csv in.csv --method zscore --out out.csv --test-frac 0.2
```

## 使用示例

- 这几列数据单位不同，帮我诊断分布并给出统一量纲的方案
- 为什么 z-score 之后数据还是偏的？该怎么处理
- 做 KNN 之前哪些特征必须标准化？min-max 和 z-score 怎么选

## 头像

⚠️ `avatars/expert.png` **尚未生成**（本次跳过图像生成）。`avatars/.gitkeep` 已占位，不影响校验与注册。可手动放入 PNG/JPG（512×512，≤500KB），或后续用 ImageGen 生成，推荐 prompt：

```
Professional cartoon-style illustration avatar, a data normalization analyst,
wearing a light shirt with rolled sleeves, standing beside floating histograms with
different scales converging into one aligned axis, holding a ruler and a slider control,
calm precise expression, small icons of scales and distribution curves in the background.
Bust shot, facing forward. Clean simple cyan-teal background.
High quality, professional, natural.
```

生成时 `size` 用 `1024x1024`，输出到 `avatars/`，重命名为 `expert.png`。

## 安装与注册

```
C:/Users/Administrator/.workbuddy/plugins/marketplaces/my-experts/plugins/data-normalization-analyst/
```

```bash
python scripts/validate_expert.py <expert-dir>
python scripts/register_expert.py <expert-dir> --session-id <session-id>
python scripts/package_expert.py <expert-dir> [output-dir]
```

## 免责声明

本专家提供方法与实现建议。所有参数须由实际数据估计；用于预测/回测时，统计量只能在训练段估计，否则构成数据泄漏。标准化不改变数据的信息量，也不修正数据质量问题（错误值、口径错误仍需单独处理）。
