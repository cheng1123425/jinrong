---
name: data-harmonization
description: 不同维度、不同单位数据的量纲统一与预处理。覆盖 z-score、Min-Max、MaxAbs、Robust、秩变换、rank-Gauss、log/Box-Cox/Yeo-Johnson、L2 归一化，以及指标正向化、熵权/TOPSIS 前的标准化、面板数据的截面/时序/分组标准化、中性化与去极值。用于判断"这堆单位不同的数据该用哪种方法统一到可比尺度""为什么标准化后还是偏""做 KNN/PCA/正则回归前必须怎么处理"，并给出可运行的纯 numpy 实现与自检。不用于替用户凭空判断数据分布，也不负责建模与预测。
agent_created: true
---

# 量纲统一与数据标准化

## 用途

把**单位不同、量级不同、分布不同**的多维数据，统一到可比较的尺度，同时保留下游模型需要的信息结构。产出是「诊断 + 方法选择 + 参数 + 可运行代码 + 验证结果」。

一句话原则：**统一量纲 ≠ 统一分布**。z-score 只把均值和方差对齐，不会改变偏态和尾巴。

## 何时使用

- 「这几列单位不一样，怎么放到一起比」
- 「z-score 和 min-max 该选哪个」
- 「为什么标准化之后数据还是偏的 / 还是有异常值」
- 「做 KNN / K-means / PCA / LASSO 之前哪些必须标准化」
- 「多指标综合评价怎么归一化、怎么正向化」
- 「面板数据按天标准化还是按股票历史标准化」
- 「训练集和测试集标准化怎么做才不泄漏」

**不用于**：建模调参、预测、替用户断言数据分布（必须先诊断）。

## 知识库结构

| 路径 | 内容 |
|---|---|
| `references/量纲处理手册.md` | 原理、11 种方法全谱（公式/范围/可逆/适用/缺点）、正向化、熵权/TOPSIS、常见错误 |
| `references/方法选择与场景对照表.md` | 按下游模型/数据形态/目标选方法，决策流程，组合方案，反例 |
| `references/面板与金融数据要点.md` | 截面 vs 时序、分组标准化、中性化≠标准化、去极值、前视偏差、单位统一 |
| `references/实现速查.md` | 纯 numpy 实现、sklearn 模板、pandas 分组、熵权法、上线注意 |
| `scripts/harmonize.py` | 可运行工具：11 种方法、fit/transform 分离、诊断与建议、CSV 批处理、自检 |
| `templates/数据处理方案模板.md` | 方案文档结构与自检表 |

## 三条铁律

1. **先诊断再选方法**：必须先看缺失率、偏度、峰度、离群比例、是否为正、是否稀疏，再决定用哪种。不默认 z-score。
2. **fit / transform 分离**：所有统计量（μ、σ、min、max、median、IQR、λ、分位点）只在训练段估计，再应用到测试段。全样本标准化是数据泄漏。
3. **报告必须完整**：方法、参数、作用范围（全局/分组/截面）、处理顺序、是否可逆，缺一项结论就不可复现。

## 工作流

### 1. 诊断
```bash
SK="C:/Users/Administrator/.workbuddy/plugins/marketplaces/my-experts/plugins/data-normalization-analyst/skills/data-harmonization"
python "$SK/scripts/harmonize.py" report --csv data.csv --use general
```
输出每列的 n / 缺失 / 均值 / 标准差 / 偏度 / 离群% / 建议方法。

### 2. 判断三件事
- **分布形态**：近似对称 / 右偏 / 重尾 / 有界 / 稀疏 / 多峰
- **下游模型**：距离类/线性+正则/PCA/NN 必须标准化；纯树模型不必
- **比较维度**：全局 / 截面（同日跨标的）/ 分组（行业）/ 时序（滚动）

### 3. 选方法
读 `方法选择与场景对照表.md` 的决策流程。常见组合：
- 右偏全正 → Box-Cox 或 log1p → z-score
- 重尾离群多 → Robust 或 winsorize → z-score
- 有界评分 / NN → Min-Max
- 稀疏 → MaxAbs
- 因子排序 → 截面 rank
- 多指标合成 → 正向化 → 统一归一化

### 4. 定顺序
```
单位/百分比统一 → 缺失处理 → 常量列剔除 → 去极值 → 分布变换 → 中性化 → 标准化
```
顺序错了会污染统计量（例如先标准化再去极值，μ/σ 已被极值带偏）。

### 5. 实现与验证
```bash
python "$SK/scripts/harmonize.py" transform --csv in.csv --method zscore --out out.csv --test-frac 0.2
python "$SK/scripts/harmonize.py" selftest
```
验证：z-score 后 mean≈0/sd≈1；Min-Max 落在 [0,1]；robust 后中位数≈0；无常量列 inf/nan；可逆方法做逆变换还原。

### 6. 出方案
按 `templates/数据处理方案模板.md` 填写，跑末尾自检。

## 输出规范

- 每列给「诊断数值 + 方法 + 理由 + 参数」，不能只写方法名。
- 明确标注作用范围：全局 / 截面 / 分组（分组键）/ 时序（窗口）。
- 明确是否可逆；不可逆（秩变换）要提醒下游无法还原。
- 金融/面板数据单列「前视偏差处理」。
- 给代码要能直接跑，并注明依赖（本机 sklearn/pandas 未装，优先给纯 numpy 版）。
- 使用简体中文。

## 典型示例

**「这几列单位不同，帮我统一」**
→ `report` 诊断 → 逐列给方法：金额类 log1p→z-score、比率类 z-score、评分类 Min-Max、离群列 Robust → 给完整顺序与代码 → 验证表。

**「为什么 z-score 之后还是偏」**
→ 解释：z-score 只改均值方差，不改偏度 → 给 `report` 输出的 skew 值 → 改用 Box-Cox/Yeo-Johnson 或 rank-Gauss → 说明 Box-Cox 要求正值。

**「做 KNN 前怎么处理」**
→ 必须标准化，否则距离被大量纲维度主导 → z-score（重尾用 rank）→ 提醒 fit 只在训练集。

**「面板数据按天还是按股票标准化」**
→ 讲清截面 vs 时序的语义差异 → 选股因子用截面 → 给 groupby(date) 代码 → 提醒跨日不可直接比。

## 异常处理

- 某列为常量（σ=0 / max=min）：返回 0 并告警，不要产生 inf。
- 全为 NaN：拒绝拟合，要求先处理缺失。
- Box-Cox 遇到 ≤0：改用 Yeo-Johnson 或先平移。
- 用户要求「全样本标准化后回测」：指出这是泄漏，给滚动方案。
- 单位/百分比口径不明：先问清 12 是 12% 还是 0.12，不猜。
