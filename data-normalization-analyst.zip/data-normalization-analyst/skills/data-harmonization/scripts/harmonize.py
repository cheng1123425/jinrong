#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
量纲统一工具箱（纯 numpy/scipy，无需 sklearn/pandas）

核心设计：**fit / transform 分离**。
所有缩放参数只在训练集上估计，再应用到测试集，避免"用未来/测试分布做标准化"的泄漏。

用法：
  python harmonize.py selftest
  python harmonize.py demo
  python harmonize.py report --csv data.csv
  python harmonize.py transform --csv in.csv --method zscore --out out.csv

支持方法：
  zscore        (x-μ)/σ                      —— 距离/线性模型/PCA 默认
  minmax        (x-min)/(max-min)            —— 有界评分、神经网络输入
  maxabs        x/max|x|                     —— 稀疏数据、保留零
  robust        (x-median)/IQR               —— 含异常值
  rank          秩转 [0,1]                   —— 重尾、非参数
  rank_gauss    秩转标准正态                 —— 重尾且要正态假设
  log1p         符号保持的对数变换           —— 右偏、非负
  boxcox        Box-Cox（需正值）            —— 右偏、要最优 λ
  yeojohnson    Yeo-Johnson（允许负值）      —— 右偏且含负值
  unit_l2       x/||x||₂                     —— 余弦相似度/文本
  none          不处理

约定：
  - 缺失值（NaN）不参与统计量估计，变换后仍为 NaN。
  - 常量列（σ=0 / max=min）返回 0，不产生 inf。
  - rank / rank_gauss 在测试集上按训练集的分位点映射（超出范围截断）。
"""

import argparse
import csv
import sys

import numpy as np

try:
    from scipy import stats as sps
    HAS_SCIPY = True
except Exception:
    HAS_SCIPY = False

EPS = 1e-12
METHODS = ["zscore", "minmax", "maxabs", "robust", "rank", "rank_gauss",
           "log1p", "boxcox", "yeojohnson", "unit_l2", "none"]


def _clean(x):
    x = np.asarray(x, dtype=float).ravel()
    return x


# ------------------------------------------------------------------ fit

def fit(x, method="zscore", feature_range=(0.0, 1.0)):
    """在训练集上估计参数，返回 dict。"""
    x = _clean(x)
    ok = x[~np.isnan(x)]
    if ok.size == 0:
        raise ValueError("全为 NaN，无法拟合")
    p = {"method": method, "n_train": int(ok.size)}

    if method == "zscore":
        p["mean"] = float(np.mean(ok))
        p["std"] = float(np.std(ok, ddof=0))
    elif method == "minmax":
        p["min"] = float(np.min(ok)); p["max"] = float(np.max(ok))
        p["lo"], p["hi"] = feature_range
    elif method == "maxabs":
        p["maxabs"] = float(np.max(np.abs(ok)))
    elif method == "robust":
        q1, q3 = np.percentile(ok, [25, 75])
        p["median"] = float(np.median(ok)); p["iqr"] = float(q3 - q1)
    elif method in ("rank", "rank_gauss"):
        p["sorted"] = np.sort(ok)
        p["n"] = int(ok.size)
    elif method == "log1p":
        m = float(np.min(ok))
        p["shift"] = 0.0 if m >= 0 else (-m + 1.0)
    elif method == "boxcox":
        if np.min(ok) <= 0:
            raise ValueError("boxcox 要求严格正值；含 0/负值时改用 yeojohnson 或先平移")
        _, lam = sps.boxcox(ok) if HAS_SCIPY else (None, None)
        p["lambda"] = float(lam) if lam is not None else 1.0
        p["need_scipy"] = not HAS_SCIPY
    elif method == "yeojohnson":
        _, lam = sps.yeojohnson(ok) if HAS_SCIPY else (None, None)
        p["lambda"] = float(lam) if lam is not None else 1.0
        p["need_scipy"] = not HAS_SCIPY
    elif method == "unit_l2":
        p["norm"] = float(np.linalg.norm(ok))
    elif method == "none":
        pass
    else:
        raise ValueError(f"未知方法: {method}")
    return p


# ------------------------------------------------------------------ transform

def transform(x, p):
    x = _clean(x)
    m = p["method"]
    out = x.copy()

    if m == "zscore":
        s = p["std"] if abs(p["std"]) > EPS else 1.0
        out = (x - p["mean"]) / s
    elif m == "minmax":
        rng = p["max"] - p["min"]
        out = np.zeros_like(x) if abs(rng) < EPS else (x - p["min"]) / rng
        out = out * (p["hi"] - p["lo"]) + p["lo"]
    elif m == "maxabs":
        d = p["maxabs"] if abs(p["maxabs"]) > EPS else 1.0
        out = x / d
    elif m == "robust":
        d = p["iqr"] if abs(p["iqr"]) > EPS else 1.0
        out = (x - p["median"]) / d
    elif m in ("rank", "rank_gauss"):
        s = p["sorted"]; n = p["n"]
        # 用训练集经验分位点映射到 (0,1)
        lo = np.searchsorted(s, x, side="right")
        hi = np.searchsorted(s, x, side="left")
        mid = (lo + hi) / 2.0
        # 连续化秩：i 对应的 mid = i+0.5，u = (i+0.5)/n 落在 (0,1) 且关于 0.5 对称
        u = np.clip(mid / n, 1e-6, 1 - 1e-6)
        if m == "rank":
            out = u
        else:
            out = sps.norm.ppf(u) if HAS_SCIPY else _norm_ppf(u)
    elif m == "log1p":
        v = x + p["shift"]
        out = np.sign(v) * np.log1p(np.abs(v))
    elif m == "boxcox":
        lam = p["lambda"]
        if not HAS_SCIPY:
            out = np.log(np.maximum(x, EPS))
        else:
            out = sps.boxcox(x, lmbda=lam)
    elif m == "yeojohnson":
        lam = p["lambda"]
        out = sps.yeojohnson(x, lmbda=lam) if HAS_SCIPY else np.sign(x) * np.log1p(np.abs(x))
    elif m == "unit_l2":
        d = p["norm"] if abs(p["norm"]) > EPS else 1.0
        out = x / d
    elif m == "none":
        out = x
    return out


def inverse(y, p):
    """仅对可逆方法（zscore/minmax/maxabs/robust/unit_l2）给出逆变换。"""
    y = _clean(y)
    m = p["method"]
    if m == "zscore":
        s = p["std"] if abs(p["std"]) > EPS else 1.0
        return y * s + p["mean"]
    if m == "minmax":
        rng = p["max"] - p["min"]
        u = (y - p["lo"]) / ((p["hi"] - p["lo"]) if abs(p["hi"] - p["lo"]) > EPS else 1.0)
        return u * rng + p["min"]
    if m == "maxabs":
        return y * (p["maxabs"] if abs(p["maxabs"]) > EPS else 1.0)
    if m == "robust":
        return y * (p["iqr"] if abs(p["iqr"]) > EPS else 1.0) + p["median"]
    if m == "unit_l2":
        return y * (p["norm"] if abs(p["norm"]) > EPS else 1.0)
    raise ValueError(f"{m} 不可逆（信息有损）")


def _norm_ppf(u):
    """无 scipy 时的正态分位近似（Acklam 有理近似）。"""
    a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
         1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00]
    b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
         6.680131188771972e+01, -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
         -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00]
    d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
         3.754408661907416e+00]
    plow, phigh = 0.02425, 1 - 0.02425
    u = np.asarray(u, dtype=float)
    out = np.empty_like(u)
    lo = u < plow
    hi = u > phigh
    mid = ~(lo | hi)
    if np.any(mid):
        q = u[mid] - 0.5; r = q * q
        num = (((((a[0]*r+a[1])*r+a[2])*r+a[3])*r+a[4])*r+a[5])*q
        den = (((((b[0]*r+b[1])*r+b[2])*r+b[3])*r+b[4])*r+1)
        out[mid] = num / den
    if np.any(lo):
        q = np.sqrt(-2*np.log(u[lo]))
        out[lo] = (((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) / ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)
    if np.any(hi):
        q = np.sqrt(-2*np.log(1-u[hi]))
        out[hi] = -(((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) / ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)
    return out


# ------------------------------------------------------------------ 诊断

def describe(x):
    x = _clean(x)
    ok = x[~np.isnan(x)]
    n = ok.size
    if n == 0:
        return {"n": 0}
    d = {
        "n": int(n),
        "missing": int(np.isnan(x).sum()),
        "mean": float(np.mean(ok)),
        "std": float(np.std(ok, ddof=0)),
        "min": float(np.min(ok)),
        "max": float(np.max(ok)),
        "median": float(np.median(ok)),
        "skew": float(sps.skew(ok)) if HAS_SCIPY else float("nan"),
        "kurt": float(sps.kurtosis(ok)) if HAS_SCIPY else float("nan"),
    }
    q1, q3 = np.percentile(ok, [25, 75])
    iqr = q3 - q1
    if iqr > 0:
        d["outlier_pct"] = float(np.mean((ok < q1 - 3*iqr) | (ok > q3 + 3*iqr)) * 100)
    else:
        d["outlier_pct"] = 0.0
    d["positive"] = bool(np.min(ok) > 0)
    return d


def suggest(d, use="general"):
    """根据分布特征与用途给建议。"""
    if d.get("n", 0) == 0:
        return "none", "无有效数据"
    reasons = []
    method = "zscore"
    if d["missing"] > 0:
        reasons.append(f"缺失 {d['missing']} 个，先插补/剔除")
    if use == "distance":
        method = "zscore"; reasons.append("距离/相似度或线性模型：必须 zscore，否则量纲主导距离")
    elif use == "bounded":
        method = "minmax"; reasons.append("有界评分/神经网络输入：minmax 到 [0,1]")
    elif use == "sparse":
        method = "maxabs"; reasons.append("稀疏数据：maxabs 保留零值结构")
    elif use == "rank":
        method = "rank"; reasons.append("重尾/非参数/需要抗异常值：秩变换")
    elif abs(d["skew"]) > 1 and d["positive"]:
        method = "boxcox" if abs(d["skew"]) > 1.5 else "log1p"
        reasons.append(f"偏度 {d['skew']:.2f}，右偏且全正：先变换分布")
    elif d["outlier_pct"] > 1.0:
        method = "robust"; reasons.append(f"离群点 {d['outlier_pct']:.2f}%：robust 缩放")
    elif abs(d["skew"]) > 1:
        method = "yeojohnson"; reasons.append(f"偏度 {d['skew']:.2f} 且含负值：yeojohnson")
    else:
        reasons.append("近似对称：zscore 通用")
    return method, "；".join(reasons)


# ------------------------------------------------------------------ 自检

def selftest(verbose=True):
    rng = np.random.default_rng(20261112)
    ok = True
    x = rng.gamma(2.0, 2.0, 500)          # 右偏正值
    xn = rng.normal(10, 3, 500)

    def chk(name, cond, info=""):
        nonlocal ok
        ok &= bool(cond)
        if verbose:
            print(f"[{'OK ' if cond else 'FAIL'}] {name} {info}")

    y = transform(xn, fit(xn, "zscore"))
    chk("zscore 均值≈0", abs(np.mean(y)) < 1e-9, f"mean={np.mean(y):.2e}")
    chk("zscore 标准差≈1", abs(np.std(y) - 1) < 1e-9, f"std={np.std(y):.6f}")

    y = transform(x, fit(x, "minmax"))
    chk("minmax 落在[0,1]", y.min() >= -1e-12 and y.max() <= 1 + 1e-12, f"[{y.min():.3f},{y.max():.3f}]")

    y = transform(x, fit(x, "robust"))
    chk("robust 中位数≈0", abs(np.median(y)) < 1e-9, f"median={np.median(y):.2e}")

    y = transform(x, fit(x, "rank"))
    chk("rank 均匀且∈(0,1)", y.min() > 0 and y.max() < 1 and abs(np.mean(y) - 0.5) < 0.02,
        f"mean={np.mean(y):.3f}")

    if HAS_SCIPY:
        y = transform(x, fit(x, "rank_gauss"))
        chk("rank_gauss 近似标准正态",
            abs(np.mean(y)) < 0.05 and abs(np.std(y) - 1) < 0.1 and abs(sps.skew(y)) < 0.15,
            f"mean={np.mean(y):.3f} std={np.std(y):.3f} skew={sps.skew(y):.3f}")
        yb = transform(x, fit(x, "boxcox"))
        chk("boxcox 降偏度", abs(sps.skew(yb)) < abs(sps.skew(x)),
            f"{sps.skew(x):.2f} -> {sps.skew(yb):.2f}")
        yj = transform(xn, fit(xn, "yeojohnson"))
        chk("yeojohnson 可用（含负值）", np.all(np.isfinite(yj)))
    else:
        y = transform(x, fit(x, "rank_gauss"))
        chk("rank_gauss 近似正态(无 scipy)", abs(np.mean(y)) < 0.05 and abs(np.std(y) - 1) < 0.12,
            f"mean={np.mean(y):.3f} std={np.std(y):.3f}")

    # 逆变换
    p = fit(xn, "zscore")
    chk("zscore 逆变换还原", np.allclose(inverse(transform(xn, p), p), xn, atol=1e-9))
    p = fit(x, "minmax")
    chk("minmax 逆变换还原", np.allclose(inverse(transform(x, p), p), x, atol=1e-9))

    # 训练/测试一致性（泄漏检查）
    p = fit(xn[:300], "zscore")
    ytr, yte = transform(xn[:300], p), transform(xn[300:], p)
    chk("测试集用训练参数", abs(np.mean(ytr)) < 1e-9 and abs(np.mean(yte)) < 0.5,
        f"train={np.mean(ytr):.3f} test={np.mean(yte):.3f}")

    # 常量列
    c = np.full(50, 7.0)
    for m in ("zscore", "minmax", "robust", "maxabs", "unit_l2"):
        yy = transform(c, fit(c, m))
        chk(f"常量列 {m} 无 inf/nan", np.all(np.isfinite(yy)))

    if verbose:
        print(f"\nscipy 可用: {HAS_SCIPY}")
        print("自检结果:", "全部通过 ✅" if ok else "存在失败 ❌")
    return ok


def demo():
    rng = np.random.default_rng(3)
    cols = {
        "市值(亿元)": rng.lognormal(3, 1, 400) * 10,
        "ROE(%)": rng.normal(12, 6, 400),
        "换手率(%)": rng.gamma(1.5, 1.2, 400),
        "评分(0-100)": rng.uniform(20, 95, 400),
    }
    print(f"{'列':<12}{'偏度':>8}{'离群%':>8}{'建议':>14}  理由")
    for k, v in cols.items():
        d = describe(v)
        m, why = suggest(d, use="general")
        print(f"{k:<12}{d['skew']:>8.2f}{d['outlier_pct']:>8.2f}{m:>14}  {why}")
    print("\n统一到 zscore 后：")
    for k, v in cols.items():
        y = transform(v, fit(v, "zscore"))
        print(f"  {k:<12}mean={np.mean(y):+.3f} std={np.std(y):.3f}")


# ------------------------------------------------------------------ CSV

def _read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.reader(f))
    header = rows[0]
    data = rows[1:]
    cols = {}
    for j, name in enumerate(header):
        vals, isnum = [], True
        for r in data:
            cell = r[j].strip() if j < len(r) else ""
            if cell == "" or cell.lower() in ("na", "nan", "null", "-"):
                vals.append(np.nan); continue
            try:
                vals.append(float(cell))
            except ValueError:
                isnum = False; break
        if isnum and vals:
            cols[name] = np.array(vals, dtype=float)
    return header, data, cols


def cmd_report(args):
    header, data, cols = _read_csv(args.csv)
    if not cols:
        print("未找到数值列。")
        return
    print(f"文件 {args.csv} | 行 {len(data)} | 数值列 {len(cols)}\n")
    print(f"{'列':<16}{'n':>5}{'缺失':>6}{'均值':>11}{'标准差':>11}{'偏度':>8}{'离群%':>8}{'建议':>12}")
    for name, v in cols.items():
        d = describe(v)
        m, _ = suggest(d, use=args.use)
        print(f"{name[:15]:<16}{d['n']:>5}{d['missing']:>6}{d['mean']:>11.3f}{d['std']:>11.3f}"
              f"{d['skew']:>8.2f}{d['outlier_pct']:>8.2f}{m:>12}")
    print("\n提示：同一模型的特征应统一到同一口径；距离/线性模型必须 zscore。")


def cmd_transform(args):
    header, data, cols = _read_csv(args.csv)
    if not cols:
        print("未找到数值列。")
        return
    split = int(len(data) * (1 - args.test_frac))
    out_rows = [header[:]]
    fitted = {}
    for name, v in cols.items():
        p = fit(v[:split], args.method)      # 只在训练段拟合
        y = transform(v, p)
        fitted[name] = (p, y)
    names = list(cols)
    for i in range(len(data)):
        row = list(data[i])
        for j, name in enumerate(names):
            idx = header.index(name)
            val = fitted[name][1][i]
            row[idx] = "" if np.isnan(val) else f"{val:.6f}"
        out_rows.append(row)
    with open(args.out, "w", newline="", encoding="utf-8-sig") as f:
        csv.writer(f).writerows(out_rows)
    print(f"已写出 {args.out} | 方法 {args.method} | 训练段 {split} 行，参数只在训练段估计")
    for name in names:
        p, y = fitted[name]
        print(f"  {name}: {args.method}, mean={np.nanmean(y):+.4f}, std={np.nanstd(y):.4f}")


def main():
    ap = argparse.ArgumentParser(description="量纲统一工具箱")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("selftest"); p.set_defaults(func=lambda a: selftest())
    p = sub.add_parser("demo"); p.set_defaults(func=lambda a: demo())

    p = sub.add_parser("report", help="诊断各列分布并给建议")
    p.add_argument("--csv", required=True)
    p.add_argument("--use", default="general",
                   choices=["general", "distance", "bounded", "sparse", "rank"])
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("transform", help="按方法批量变换 CSV")
    p.add_argument("--csv", required=True)
    p.add_argument("--method", default="zscore", choices=METHODS)
    p.add_argument("--out", required=True)
    p.add_argument("--test-frac", type=float, default=0.0)
    p.set_defaults(func=cmd_transform)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
